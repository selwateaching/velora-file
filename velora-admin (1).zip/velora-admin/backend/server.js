require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();

// §27 — Sécurité de base
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));

// §27 — Limitation du nombre de requêtes (protection contre les abus)
const limiteurGeneral = rateLimit({ windowMs: 60_000, max: 300 });
app.use('/api', limiteurGeneral);

const limiteurLogin = rateLimit({ windowMs: 15 * 60_000, max: 10, message: { error: 'Trop de tentatives, réessayez plus tard.' } });
app.use('/api/auth/login', limiteurLogin);

app.use('/api/auth', require('./routes/auth'));
app.use('/api/clients', require('./routes/clients'));
app.use('/api/applications', require('./routes/applications'));
app.use('/api/forfaits', require('./routes/forfaits'));
app.use('/api/fournisseurs', require('./routes/fournisseurs'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/rentabilite', require('./routes/rentabilite'));
app.use('/api/abonnements', require('./routes/abonnements'));
app.use('/api/paiements', require('./routes/paiements'));
app.use('/api', require('./routes/divers')); // alertes, crédits, consommations, journal, paramètres, recherche, rapport

// §29 — Gestion des erreurs propre, jamais de détail technique exposé au client
app.use((err, req, res, next) => {
  console.error('[ERREUR]', err); // détails techniques -> logs serveur uniquement
  res.status(500).json({ error: "Une erreur interne est survenue. Veuillez réessayer dans quelques instants." });
});

// Sert le frontend statique
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Velora Admin — serveur démarré sur http://localhost:${PORT}`);
});
