const { collection } = require('../db/store');

/**
 * §12 — TARIFICATION DES FOURNISSEURS IA
 * Les prix ne sont jamais écrits en dur dans le code métier.
 * Ils sont lus dans la collection `tarifsIA`, avec historique
 * (dateEffet / dateFin) pour pouvoir recalculer correctement
 * les anciens coûts même si les prix ont changé depuis.
 *
 * Structure d'un document tarifsIA :
 * {
 *   fournisseur: "anthropic",
 *   modele: "claude-sonnet-5",
 *   prixEntree: 3.0,   // par million de tokens (unite ci-dessous)
 *   prixSortie: 15.0,
 *   unite: "par_million_tokens",
 *   dateEffet: "2026-01-01T00:00:00.000Z",
 *   dateFin: null,     // null = tarif actif
 *   statut: "actif"
 * }
 */

async function getTarifApplicable(fournisseur, modele, atDate = new Date()) {
  const tarifs = await collection('tarifsIA').find({ fournisseur, modele });
  const iso = atDate.toISOString();
  const applicables = tarifs.filter(
    (t) => t.dateEffet <= iso && (!t.dateFin || t.dateFin > iso)
  );
  if (applicables.length === 0) return null;
  // le plus récent dateEffet gagne
  return applicables.sort((a, b) => (a.dateEffet < b.dateEffet ? 1 : -1))[0];
}

function calculerCout(tarif, tokensEntree, tokensSortie) {
  if (!tarif) return null;
  const diviseur = tarif.unite === 'par_million_tokens' ? 1_000_000 : 1000;
  const coutEntree = (tokensEntree / diviseur) * tarif.prixEntree;
  const coutSortie = (tokensSortie / diviseur) * tarif.prixSortie;
  return Number((coutEntree + coutSortie).toFixed(6));
}

module.exports = { getTarifApplicable, calculerCout };
