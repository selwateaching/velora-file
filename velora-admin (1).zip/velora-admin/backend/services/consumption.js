const { collection } = require('../db/store');
const { getTarifApplicable, calculerCout } = require('./pricing');

function periodeCourante(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`; // ex: "2026-09"
}

const SEUILS_DEFAUT = [50, 80, 90, 100];

/**
 * §13 — CONTRÔLE DES LIMITES (étapes 1 à 9)
 * Appelé AVANT tout appel réel au fournisseur IA.
 * Retourne { autorise: bool, raison, compteur, forfait, limite }
 */
async function verifierAutorisation(clientId, applicationId) {
  const client = await collection('clients').findById(clientId);
  if (!client) return { autorise: false, raison: 'Client introuvable.' };
  if (client.statut === 'suspendu') {
    return { autorise: false, raison: 'Client suspendu — accès IA refusé.' };
  }

  const application = await collection('applications').findById(applicationId);
  if (!application) return { autorise: false, raison: 'Application introuvable.' };
  if (application.clientId !== clientId) {
    return { autorise: false, raison: "Cette application n'appartient pas à ce client." };
  }
  if (application.statut !== 'active') {
    return { autorise: false, raison: `Application non active (statut: ${application.statut}).` };
  }

  const forfait = await collection('forfaits').findById(client.forfaitId);
  if (!forfait) return { autorise: false, raison: 'Aucun forfait associé à ce client.' };

  const periode = periodeCourante();
  let compteur = await collection('compteurs').findOne({ clientId, periode });
  if (!compteur) {
    compteur = await collection('compteurs').insert({
      clientId, periode, tokensConsommes: 0, coutCumule: 0, demandes: 0,
    });
  }

  // Crédits supplémentaires disponibles (§16) — ajoutent à la limite du forfait
  const credits = await collection('credits').find({ clientId, periode });
  const creditsTokensDisponibles = credits.reduce((s, c) => s + Math.max(0, (c.quantiteTokens || 0) - (c.utiliseTokens || 0)), 0);

  const limiteTotale = forfait.limiteTokens + creditsTokensDisponibles;
  const pourcentage = limiteTotale > 0 ? (compteur.tokensConsommes / limiteTotale) * 100 : 100;

  if (compteur.tokensConsommes >= limiteTotale) {
    const comportement = forfait.comportementLimite || 'blocage';
    if (comportement === 'blocage') {
      return { autorise: false, raison: 'Limite IA atteinte.', compteur, forfait, limiteTotale, pourcentage };
    }
    if (comportement === 'validation') {
      return { autorise: false, raison: 'Limite atteinte — validation administrateur requise.', compteur, forfait, limiteTotale, pourcentage, requiertValidation: true };
    }
    // "credit_supplementaire" ou "forfait_superieur" : on laisse passer mais on signale
    return { autorise: true, raison: 'Limite dépassée — mode dérogatoire actif.', compteur, forfait, limiteTotale, pourcentage, depassement: true };
  }

  return { autorise: true, compteur, forfait, limiteTotale, pourcentage };
}

/**
 * §11 — Enregistrer une consommation IA réelle après appel au fournisseur.
 * §14 — Génère automatiquement les alertes de seuil (50/80/90/100%).
 */
async function enregistrerConsommation({
  clientId, applicationId, fournisseur, modele,
  tokensEntree, tokensSortie, statut = 'succes', erreur = null,
}) {
  const tokensTotal = (tokensEntree || 0) + (tokensSortie || 0);
  const tarif = await getTarifApplicable(fournisseur, modele);
  const cout = calculerCout(tarif, tokensEntree || 0, tokensSortie || 0);

  const entree = await collection('consommations').insert({
    clientId, applicationId, fournisseur, modele,
    tokensEntree: tokensEntree || 0,
    tokensSortie: tokensSortie || 0,
    tokensTotal,
    cout: cout ?? null,
    statut, erreur,
    date: new Date().toISOString(),
  });

  const periode = periodeCourante();
  let compteur = await collection('compteurs').findOne({ clientId, periode });
  if (!compteur) {
    compteur = await collection('compteurs').insert({ clientId, periode, tokensConsommes: 0, coutCumule: 0, demandes: 0 });
  }
  const nouveauTotal = compteur.tokensConsommes + tokensTotal;
  const nouveauCout = compteur.coutCumule + (cout || 0);
  const nouveauCompteur = await collection('compteurs').update(compteur.id, {
    tokensConsommes: nouveauTotal,
    coutCumule: nouveauCout,
    demandes: compteur.demandes + 1,
  });

  await verifierEtCreerAlertes(clientId, nouveauCompteur);

  return { consommation: entree, compteur: nouveauCompteur };
}

/**
 * §14 — Seuils d'alerte configurables (défaut 50/80/90/100%).
 * §22 — Crée une alerte si un seuil vient d'être franchi (pas de doublon pour la période).
 */
async function verifierEtCreerAlertes(clientId, compteur) {
  const client = await collection('clients').findById(clientId);
  if (!client) return;
  const forfait = await collection('forfaits').findById(client.forfaitId);
  if (!forfait) return;

  const parametres = await collection('parametres').findOne({ cle: 'seuilsAlerte' });
  const seuils = parametres?.valeur || SEUILS_DEFAUT;

  const pourcentage = forfait.limiteTokens > 0 ? (compteur.tokensConsommes / forfait.limiteTokens) * 100 : 0;

  for (const seuil of seuils.sort((a, b) => a - b)) {
    if (pourcentage >= seuil) {
      const dejaExistante = await collection('alertes').findOne({
        clientId, periode: compteur.periode, type: `seuil_${seuil}`,
      });
      if (!dejaExistante) {
        const categorie = seuil >= 100 ? 'Limite IA atteinte' : seuil >= 80 ? 'Consommation élevée' : 'Information';
        const gravite = seuil >= 100 ? 'rouge' : seuil >= 80 ? 'orange' : 'bleu';
        await collection('alertes').insert({
          clientId,
          type: `seuil_${seuil}`,
          categorie,
          gravite,
          periode: compteur.periode,
          message: `${client.nomEntreprise} a atteint ${seuil}% de son forfait IA (${compteur.tokensConsommes.toLocaleString('fr-FR')} / ${forfait.limiteTokens.toLocaleString('fr-FR')} tokens).`,
          statut: 'nouvelle',
          date: new Date().toISOString(),
        });
      }
    }
  }
}

module.exports = { periodeCourante, verifierAutorisation, enregistrerConsommation, verifierEtCreerAlertes, SEUILS_DEFAUT };
