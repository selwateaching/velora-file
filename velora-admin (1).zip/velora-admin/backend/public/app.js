/* ============================================================
   VELORA ADMIN — Frontend
   Toutes les données affichées proviennent de l'API réelle.
   Aucune donnée n'est générée côté client.
   ============================================================ */

const API = '/api';
let TOKEN = localStorage.getItem('velora_token') || null;
let ADMIN = null;

/* ---------------- Client API générique ---------------- */
async function api(path, options = {}) {
  const res = await fetch(API + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {}),
      ...(options.headers || {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch (_) { /* pas de corps */ }
  if (!res.ok) {
    throw new Error((data && data.error) || `Erreur (${res.status})`);
  }
  return data;
}

/* ---------------- Toasts ---------------- */
function toast(message, type = 'succes') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

/* ---------------- Formatage ---------------- */
const fmtEuros = (n) => (n ?? 0).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
const fmtNombre = (n) => (n ?? 0).toLocaleString('fr-FR');
const fmtDate = (d) => d ? new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const fmtDateHeure = (d) => d ? new Date(d).toLocaleString('fr-FR') : '—';

function badgeStatut(statut) {
  return `<span class="badge-statut statut-${statut}">${statut.replace('_', ' ')}</span>`;
}

/* ---------------- Authentification ---------------- */
document.getElementById('form-login').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const motDePasse = document.getElementById('login-motdepasse').value;
  const err = document.getElementById('login-erreur');
  err.textContent = '';
  try {
    const data = await api('/auth/login', { method: 'POST', body: { email, motDePasse } });
    TOKEN = data.token;
    ADMIN = data.admin;
    localStorage.setItem('velora_token', TOKEN);
    demarrerApp();
  } catch (e2) {
    err.textContent = e2.message;
  }
});

document.getElementById('btn-mdp-oublie').addEventListener('click', async () => {
  const email = prompt('Entrez votre adresse email pour recevoir un lien de réinitialisation :');
  if (!email) return;
  try {
    await api('/auth/mot-de-passe-oublie', { method: 'POST', body: { email } });
    toast('Si ce compte existe, un email a été envoyé.');
  } catch (e) { toast(e.message, 'erreur'); }
});

document.getElementById('btn-logout').addEventListener('click', async () => {
  try { await api('/auth/logout', { method: 'POST' }); } catch (_) {}
  localStorage.removeItem('velora_token');
  TOKEN = null;
  location.reload();
});

async function demarrerApp() {
  try {
    ADMIN = await api('/auth/me');
  } catch (e) {
    localStorage.removeItem('velora_token');
    document.getElementById('ecran-login').classList.remove('hidden');
    document.getElementById('app').classList.add('hidden');
    return;
  }
  document.getElementById('ecran-login').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  document.getElementById('admin-info').textContent = ADMIN.email;
  router();
  rafraichirBadgeAlertes();
}

/* ---------------- Routeur simple par hash ---------------- */
window.addEventListener('hashchange', router);
document.querySelectorAll('.nav-item').forEach((a) => {
  a.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach((x) => x.classList.remove('actif'));
    a.classList.add('actif');
  });
});

const VUES = {
  dashboard: vueDashboard,
  clients: vueClients,
  applications: vueApplications,
  forfaits: vueForfaits,
  fournisseurs: vueFournisseurs,
  abonnements: vueAbonnements,
  rentabilite: vueRentabilite,
  alertes: vueAlertes,
  journal: vueJournal,
  parametres: vueParametres,
};

function router() {
  const hash = (location.hash || '#dashboard').replace('#', '');
  const vue = VUES[hash] || vueDashboard;
  const conteneur = document.getElementById('vue');
  conteneur.innerHTML = '<p style="color:var(--texte-attenue)">Chargement...</p>';
  vue(conteneur).catch((e) => {
    conteneur.innerHTML = `<p style="color:var(--rouge)">Erreur : ${e.message}</p>`;
  });
}

async function rafraichirBadgeAlertes() {
  try {
    const alertes = await api('/alertes?statut=nouvelle');
    const badge = document.getElementById('badge-alertes');
    if (alertes.length > 0) {
      badge.textContent = alertes.length;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  } catch (_) {}
}

/* ============================================================
   VUE : TABLEAU DE BORD (§7, §45)
   ============================================================ */
async function vueDashboard(conteneur) {
  const d = await api('/dashboard');
  conteneur.innerHTML = `
    <h1 class="titre-page">VELORA IA — Administration</h1>
    <p class="sous-titre-page">Vue d'ensemble en temps réel</p>

    <div class="grille-cartes">
      <div class="carte-stat"><div class="label">CA du mois</div><div class="valeur">${fmtEuros(d.finance.revenusMois)}</div></div>
      <div class="carte-stat"><div class="label">Coût IA</div><div class="valeur">${fmtEuros(d.finance.coutsIA)}</div></div>
      <div class="carte-stat"><div class="label">Marge estimée</div><div class="valeur">${fmtEuros(d.finance.margeEstimee)}</div></div>
      <div class="carte-stat"><div class="label">Clients</div><div class="valeur">${d.clients.total}</div><div class="detail">${d.clients.actifs} actifs · ${d.clients.suspendus} suspendus</div></div>
      <div class="carte-stat"><div class="label">Applications</div><div class="valeur">${d.applications.total}</div><div class="detail">${d.applications.avecIA} avec IA</div></div>
    </div>

    <div class="section-titre">Consommation IA</div>
    <div class="grille-cartes">
      <div class="carte-stat"><div class="label">Tokens ce mois</div><div class="valeur">${fmtNombre(d.ia.consommationMoisTokens)}</div></div>
      <div class="carte-stat"><div class="label">Demandes IA</div><div class="valeur">${fmtNombre(d.ia.nombreDemandes)}</div></div>
      <div class="carte-stat"><div class="label"><span class="point point-orange"></span>Proches de la limite</div><div class="valeur">${d.ia.clientsProchesLimite}</div></div>
      <div class="carte-stat"><div class="label"><span class="point point-rouge"></span>Limite atteinte</div><div class="valeur">${d.ia.clientsLimiteAtteinte}</div></div>
    </div>

    <div class="chart-conteneur"><canvas id="chart-evolution"></canvas></div>

    <div class="section-titre">Abonnements</div>
    <div class="grille-cartes">
      <div class="carte-stat"><div class="label">Actifs</div><div class="valeur">${d.abonnements.actifs}</div></div>
      <div class="carte-stat"><div class="label">Échéance proche (7j)</div><div class="valeur">${d.abonnements.echeanceProche}</div></div>
      <div class="carte-stat"><div class="label">Revenu récurrent mensuel</div><div class="valeur">${fmtEuros(d.abonnements.revenuMensuel)}</div></div>
      <div class="carte-stat"><div class="label">Alertes non lues</div><div class="valeur">${d.alertesNouvelles}</div></div>
    </div>
  `;

  const ctx = document.getElementById('chart-evolution');
  if (window.Chart && d.evolutionMensuelle.length) {
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: d.evolutionMensuelle.map((e) => e.periode),
        datasets: [
          { label: 'Tokens consommés', data: d.evolutionMensuelle.map((e) => e.tokens), borderColor: '#5b8cff', backgroundColor: 'rgba(91,140,255,0.15)', tension: 0.3, fill: true, yAxisID: 'y' },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { labels: { color: '#93a0c2' } } },
        scales: {
          x: { ticks: { color: '#93a0c2' }, grid: { color: '#24304d' } },
          y: { ticks: { color: '#93a0c2' }, grid: { color: '#24304d' } },
        },
      },
    });
  } else {
    ctx.parentElement.innerHTML = '<p style="color:var(--texte-attenue)">Pas encore assez de données pour un graphique d\'évolution.</p>';
  }
}

/* ============================================================
   VUE : CLIENTS (§8)
   ============================================================ */
async function vueClients(conteneur) {
  const [clients, forfaits] = await Promise.all([api('/clients'), api('/forfaits')]);
  const forfaitById = Object.fromEntries(forfaits.map((f) => [f.id, f]));

  conteneur.innerHTML = `
    <h1 class="titre-page">Clients</h1>
    <p class="sous-titre-page">${clients.length} client(s)</p>
    <div class="toolbar">
      <input type="text" id="recherche-clients" placeholder="Rechercher un client..." style="width:280px" />
      <button class="btn btn-primary" id="btn-nouveau-client">+ Nouveau client</button>
    </div>
    <div class="panneau">
      <table>
        <thead><tr><th>Entreprise</th><th>Responsable</th><th>Email</th><th>Forfait</th><th>Statut</th><th></th></tr></thead>
        <tbody id="corps-clients"></tbody>
      </table>
    </div>
  `;

  function render(liste) {
    document.getElementById('corps-clients').innerHTML = liste.map((c) => `
      <tr>
        <td>${c.nomEntreprise} ${c.demo ? '<span class="badge-demo">DÉMO</span>' : ''}</td>
        <td>${c.nomResponsable || '—'}</td>
        <td>${c.email}</td>
        <td>${forfaitById[c.forfaitId]?.nom || '—'}</td>
        <td>${badgeStatut(c.statut)}</td>
        <td>
          <button class="lien-action" data-voir="${c.id}">Détails</button>
          ${c.statut === 'actif' ? `<button class="lien-action" data-suspendre="${c.id}">Suspendre</button>` : `<button class="lien-action" data-reactiver="${c.id}">Réactiver</button>`}
        </td>
      </tr>
    `).join('') || '<tr><td colspan="6" style="color:var(--texte-attenue)">Aucun client.</td></tr>';

    liste_bind();
  }

  function liste_bind() {
    document.querySelectorAll('[data-voir]').forEach((b) => b.onclick = () => ouvrirDetailClient(b.dataset.voir, forfaitById));
    document.querySelectorAll('[data-suspendre]').forEach((b) => b.onclick = async () => {
      if (!confirm('Suspendre ce client ? Ses appels IA seront bloqués.')) return;
      await api(`/clients/${b.dataset.suspendre}/suspendre`, { method: 'POST' });
      toast('Client suspendu.');
      router();
    });
    document.querySelectorAll('[data-reactiver]').forEach((b) => b.onclick = async () => {
      await api(`/clients/${b.dataset.reactiver}/reactiver`, { method: 'POST' });
      toast('Client réactivé.');
      router();
    });
  }

  render(clients);
  document.getElementById('recherche-clients').addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase();
    render(clients.filter((c) => [c.nomEntreprise, c.email, c.nomResponsable].some((v) => (v || '').toLowerCase().includes(q))));
  });

  document.getElementById('btn-nouveau-client').addEventListener('click', () => {
    ouvrirModal(`
      <h2>Nouveau client</h2>
      <label>Nom de l'entreprise *</label><input id="m-nom" required />
      <label>Nom du responsable</label><input id="m-resp" />
      <label>Email *</label><input id="m-email" type="email" required />
      <label>Téléphone</label><input id="m-tel" />
      <label>Pays</label><input id="m-pays" value="France" />
      <label>Forfait</label>
      <select id="m-forfait">${forfaits.map((f) => `<option value="${f.id}">${f.nom} (${fmtEuros(f.prix)}/mois)</option>`).join('')}</select>
      <label>Notes internes</label><textarea id="m-notes" rows="2"></textarea>
    `, async () => {
      const nomEntreprise = document.getElementById('m-nom').value;
      const email = document.getElementById('m-email').value;
      if (!nomEntreprise || !email) return toast('Nom et email requis.', 'erreur');
      await api('/clients', { method: 'POST', body: {
        nomEntreprise, email,
        nomResponsable: document.getElementById('m-resp').value,
        telephone: document.getElementById('m-tel').value,
        pays: document.getElementById('m-pays').value,
        forfaitId: document.getElementById('m-forfait').value,
        notes: document.getElementById('m-notes').value,
      }});
      toast('Client créé.');
      fermerModal();
      router();
    });
  });
}

async function ouvrirDetailClient(id, forfaitById) {
  const client = await api(`/clients/${id}`);
  const compteurs = await api(`/compteurs?clientId=${id}`);
  const compteurMois = compteurs[0];
  const forfait = forfaitById[client.forfaitId];
  const pct = forfait && compteurMois ? Math.min(100, (compteurMois.tokensConsommes / forfait.limiteTokens) * 100) : 0;
  const couleur = pct >= 100 ? 'var(--rouge)' : pct >= 80 ? 'var(--orange)' : 'var(--vert)';

  ouvrirModal(`
    <h2>${client.nomEntreprise}</h2>
    <p style="color:var(--texte-attenue);font-size:13px">${client.email} · ${client.nomResponsable || '—'} · ${client.pays || ''}</p>
    <p>${badgeStatut(client.statut)}</p>

    <label>Utilisation IA du mois (${forfait?.nom || '—'})</label>
    <div class="barre-progression"><div class="remplissage" style="width:${pct}%;background:${couleur}"></div></div>
    <p style="font-size:12px;color:var(--texte-attenue);margin-top:6px">
      ${compteurMois ? fmtNombre(compteurMois.tokensConsommes) : 0} / ${forfait ? fmtNombre(forfait.limiteTokens) : '—'} tokens
      (${fmtEuros(compteurMois?.coutCumule || 0)})
    </p>

    <label>Applications (${client.applications.length})</label>
    <div style="font-size:13px">${client.applications.map((a) => `${a.nom} ${badgeStatut(a.statut)}`).join('<br/>') || '—'}</div>

    <label>Changer de forfait</label>
    <select id="m-nouveau-forfait">${Object.values(forfaitById).map((f) => `<option value="${f.id}" ${f.id === client.forfaitId ? 'selected' : ''}>${f.nom}</option>`).join('')}</select>
  `, async () => {
    const nouveauForfaitId = document.getElementById('m-nouveau-forfait').value;
    if (nouveauForfaitId !== client.forfaitId) {
      await api(`/clients/${id}/changer-forfait`, { method: 'POST', body: { nouveauForfaitId, raison: 'Modification manuelle depuis Velora Admin' } });
      toast('Forfait mis à jour.');
      router();
    }
    fermerModal();
  }, 'Enregistrer');
}

/* ============================================================
   VUE : APPLICATIONS (§9)
   ============================================================ */
async function vueApplications(conteneur) {
  const [apps, clients] = await Promise.all([api('/applications'), api('/clients')]);
  const clientById = Object.fromEntries(clients.map((c) => [c.id, c]));

  conteneur.innerHTML = `
    <h1 class="titre-page">Applications</h1>
    <p class="sous-titre-page">${apps.length} application(s)</p>
    <div class="toolbar">
      <div></div>
      <button class="btn btn-primary" id="btn-nouvelle-app">+ Nouvelle application</button>
    </div>
    <div class="panneau">
      <table>
        <thead><tr><th>Application</th><th>Client</th><th>IA</th><th>Environnement</th><th>Statut</th><th></th></tr></thead>
        <tbody>
          ${apps.map((a) => `
            <tr>
              <td>${a.nom} ${a.demo ? '<span class="badge-demo">DÉMO</span>' : ''}</td>
              <td>${clientById[a.clientId]?.nomEntreprise || '—'}</td>
              <td>${a.utiliseIA ? `${a.fournisseurIA} / ${a.modeleIA}` : '—'}</td>
              <td>${a.environnement}</td>
              <td>${badgeStatut(a.statut)}</td>
              <td>
                <select data-statut-app="${a.id}">
                  ${['active', 'suspendue', 'maintenance', 'archivée'].map((s) => `<option value="${s}" ${s === a.statut ? 'selected' : ''}>${s}</option>`).join('')}
                </select>
                <button class="lien-action" data-voir-cle="${a.id}" data-cle="${a.appKey}">Clé</button>
              </td>
            </tr>
          `).join('') || '<tr><td colspan="6" style="color:var(--texte-attenue)">Aucune application.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;

  document.querySelectorAll('[data-statut-app]').forEach((sel) => sel.onchange = async () => {
    await api(`/applications/${sel.dataset.statutApp}/statut`, { method: 'POST', body: { statut: sel.value } });
    toast('Statut mis à jour.');
  });

  document.querySelectorAll('[data-voir-cle]').forEach((b) => b.onclick = () => {
    ouvrirModal(`
      <h2>Clé d'application</h2>
      <p style="font-size:13px;color:var(--texte-attenue)">Utilisez cette clé dans l'en-tête <code>X-Velora-App-Key</code> depuis votre application cliente. Ne la partagez jamais publiquement.</p>
      <input readonly value="${b.dataset.cle || '(aucune — cliquez sur régénérer)'}" onclick="this.select()" />
      <button class="lien-action" id="btn-regen" style="margin-top:10px">Régénérer la clé (invalide l'ancienne)</button>
    `, () => fermerModal(), 'Fermer');
    document.getElementById('btn-regen').onclick = async () => {
      if (!confirm('Régénérer la clé ? L\'ancienne cessera de fonctionner immédiatement.')) return;
      const r = await api(`/ai/applications/${b.dataset.voirCle}/regenerer-cle`, { method: 'POST' });
      toast('Nouvelle clé générée.');
      fermerModal();
      router();
    };
  });

  document.getElementById('btn-nouvelle-app').addEventListener('click', () => {
    ouvrirModal(`
      <h2>Nouvelle application</h2>
      <label>Nom *</label><input id="m-nom" required placeholder="ex: Garage IA" />
      <label>Client *</label>
      <select id="m-client">${clients.map((c) => `<option value="${c.id}">${c.nomEntreprise}</option>`).join('')}</select>
      <label>Type</label><input id="m-type" placeholder="gestion, analyse, éducatif..." />
      <label><input type="checkbox" id="m-ia" style="width:auto;display:inline" /> Utilise l'IA</label>
      <div id="bloc-ia" class="hidden">
        <label>Fournisseur IA</label>
        <select id="m-fournisseur"><option value="anthropic">Anthropic</option><option value="openai">OpenAI</option><option value="google">Google</option></select>
        <label>Modèle</label><input id="m-modele" placeholder="ex: claude-sonnet-5" />
      </div>
      <label>URL</label><input id="m-url" placeholder="https://..." />
    `, async () => {
      const nom = document.getElementById('m-nom').value;
      const clientId = document.getElementById('m-client').value;
      if (!nom || !clientId) return toast('Nom et client requis.', 'erreur');
      await api('/applications', { method: 'POST', body: {
        nom, clientId, type: document.getElementById('m-type').value,
        utiliseIA: document.getElementById('m-ia').checked,
        fournisseurIA: document.getElementById('m-fournisseur').value,
        modeleIA: document.getElementById('m-modele').value,
        url: document.getElementById('m-url').value,
      }});
      toast('Application créée.');
      fermerModal();
      router();
    });
    document.getElementById('m-ia').addEventListener('change', (e) => {
      document.getElementById('bloc-ia').classList.toggle('hidden', !e.target.checked);
    });
  });
}

/* ============================================================
   VUE : FORFAITS (§10)
   ============================================================ */
async function vueForfaits(conteneur) {
  const forfaits = await api('/forfaits');
  conteneur.innerHTML = `
    <h1 class="titre-page">Forfaits</h1>
    <p class="sous-titre-page">Configurables sans toucher au code</p>
    <div class="toolbar"><div></div><button class="btn btn-primary" id="btn-nouveau-forfait">+ Nouveau forfait</button></div>
    <div class="grille-cartes">
      ${forfaits.map((f) => `
        <div class="panneau">
          <div style="display:flex;justify-content:space-between;align-items:start">
            <div>
              <div style="font-weight:700;font-size:16px">${f.nom}</div>
              <div style="color:var(--accent-clair);font-size:22px;font-weight:700;margin:6px 0">${fmtEuros(f.prix)}<span style="font-size:12px;color:var(--texte-attenue)">/${f.periode === 'annuel' ? 'an' : 'mois'}</span></div>
            </div>
            ${badgeStatut(f.statut)}
          </div>
          <p style="font-size:13px;color:var(--texte-attenue)">Limite : ${fmtNombre(f.limiteTokens)} tokens/mois</p>
          <p style="font-size:13px;color:var(--texte-attenue)">À 100% : <strong>${{blocage:'Blocage',validation:'Validation admin',credit_supplementaire:'Recharge possible',forfait_superieur:'Upgrade proposé'}[f.comportementLimite]}</strong></p>
          <button class="lien-action" data-modifier="${f.id}">Modifier</button>
        </div>
      `).join('')}
    </div>
  `;

  function ouvrirFormulaire(forfait) {
    ouvrirModal(`
      <h2>${forfait ? 'Modifier le forfait' : 'Nouveau forfait'}</h2>
      <label>Nom *</label><input id="m-nom" value="${forfait?.nom || ''}" required />
      <label>Prix (€) *</label><input id="m-prix" type="number" step="0.01" value="${forfait?.prix ?? ''}" required />
      <label>Période</label>
      <select id="m-periode"><option value="mensuel" ${forfait?.periode === 'mensuel' ? 'selected' : ''}>Mensuel</option><option value="annuel" ${forfait?.periode === 'annuel' ? 'selected' : ''}>Annuel</option></select>
      <label>Limite IA (tokens/mois) *</label><input id="m-limite" type="number" value="${forfait?.limiteTokens ?? ''}" required />
      <label>Comportement à 100%</label>
      <select id="m-comportement">
        ${['blocage', 'validation', 'credit_supplementaire', 'forfait_superieur'].map((v) => `<option value="${v}" ${forfait?.comportementLimite === v ? 'selected' : ''}>${{blocage:'Blocage',validation:'Validation admin',credit_supplementaire:'Recharge possible',forfait_superieur:'Upgrade proposé'}[v]}</option>`).join('')}
      </select>
    `, async () => {
      const body = {
        nom: document.getElementById('m-nom').value,
        prix: Number(document.getElementById('m-prix').value),
        periode: document.getElementById('m-periode').value,
        limiteTokens: Number(document.getElementById('m-limite').value),
        comportementLimite: document.getElementById('m-comportement').value,
      };
      if (!body.nom || !body.limiteTokens) return toast('Champs requis manquants.', 'erreur');
      if (forfait) await api(`/forfaits/${forfait.id}`, { method: 'PUT', body });
      else await api('/forfaits', { method: 'POST', body });
      toast('Forfait enregistré.');
      fermerModal();
      router();
    });
  }

  document.getElementById('btn-nouveau-forfait').onclick = () => ouvrirFormulaire(null);
  document.querySelectorAll('[data-modifier]').forEach((b) => b.onclick = () => ouvrirFormulaire(forfaits.find((f) => f.id === b.dataset.modifier)));
}

/* ============================================================
   VUE : FOURNISSEURS IA (§12)
   ============================================================ */
async function vueFournisseurs(conteneur) {
  const tarifs = await api('/fournisseurs/tarifs');
  conteneur.innerHTML = `
    <h1 class="titre-page">Fournisseurs IA</h1>
    <p class="sous-titre-page">Tarifs centralisés et historisés — jamais codés en dur</p>
    <div class="toolbar"><div></div><button class="btn btn-primary" id="btn-nouveau-tarif">+ Mettre à jour un tarif</button></div>
    <div class="panneau">
      <table>
        <thead><tr><th>Fournisseur</th><th>Modèle</th><th>Prix entrée</th><th>Prix sortie</th><th>Unité</th><th>Statut</th><th>Depuis</th></tr></thead>
        <tbody>
          ${tarifs.map((t) => `
            <tr>
              <td>${t.fournisseur}</td><td>${t.modele}</td>
              <td>${fmtEuros(t.prixEntree)}</td><td>${fmtEuros(t.prixSortie)}</td>
              <td style="font-size:12px;color:var(--texte-attenue)">${t.unite.replace(/_/g, ' ')}</td>
              <td>${badgeStatut(t.statut)}</td>
              <td>${fmtDate(t.dateEffet)}</td>
            </tr>
          `).join('') || '<tr><td colspan="7" style="color:var(--texte-attenue)">Aucun tarif configuré.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;

  document.getElementById('btn-nouveau-tarif').onclick = () => {
    ouvrirModal(`
      <h2>Mettre à jour un tarif IA</h2>
      <p style="font-size:12px;color:var(--texte-attenue)">L'ancien tarif est automatiquement archivé (historique conservé pour recalculer les coûts passés).</p>
      <label>Fournisseur *</label>
      <select id="m-fournisseur"><option value="anthropic">Anthropic</option><option value="openai">OpenAI</option><option value="google">Google</option></select>
      <label>Modèle *</label><input id="m-modele" placeholder="ex: claude-sonnet-5" required />
      <label>Prix entrée (par million de tokens) *</label><input id="m-entree" type="number" step="0.01" required />
      <label>Prix sortie (par million de tokens) *</label><input id="m-sortie" type="number" step="0.01" required />
    `, async () => {
      const body = {
        fournisseur: document.getElementById('m-fournisseur').value,
        modele: document.getElementById('m-modele').value,
        prixEntree: Number(document.getElementById('m-entree').value),
        prixSortie: Number(document.getElementById('m-sortie').value),
        unite: 'par_million_tokens',
      };
      if (!body.modele) return toast('Modèle requis.', 'erreur');
      await api('/fournisseurs/tarifs', { method: 'POST', body });
      toast('Tarif mis à jour.');
      fermerModal();
      router();
    });
  };
}

/* ============================================================
   VUE : ABONNEMENTS (§19)
   ============================================================ */
async function vueAbonnements(conteneur) {
  const [abos, clients, forfaits] = await Promise.all([api('/abonnements'), api('/clients'), api('/forfaits')]);
  const clientById = Object.fromEntries(clients.map((c) => [c.id, c]));
  const forfaitById = Object.fromEntries(forfaits.map((f) => [f.id, f]));

  conteneur.innerHTML = `
    <h1 class="titre-page">Abonnements</h1>
    <p class="sous-titre-page">${abos.length} abonnement(s)</p>
    <div class="panneau">
      <table>
        <thead><tr><th>Client</th><th>Forfait</th><th>Prix</th><th>Prochaine échéance</th><th>Statut</th><th></th></tr></thead>
        <tbody>
          ${abos.map((a) => `
            <tr>
              <td>${clientById[a.clientId]?.nomEntreprise || '—'} ${a.demo ? '<span class="badge-demo">DÉMO</span>' : ''}</td>
              <td>${forfaitById[a.forfaitId]?.nom || '—'}</td>
              <td>${fmtEuros(a.prix)}</td>
              <td>${fmtDate(a.prochainEcheance)}</td>
              <td>${badgeStatut(a.statut)}</td>
              <td>
                <button class="lien-action" data-renouveler="${a.id}">Renouveler</button>
                <button class="lien-action" data-suspendre-abo="${a.id}">Suspendre</button>
              </td>
            </tr>
          `).join('') || '<tr><td colspan="6" style="color:var(--texte-attenue)">Aucun abonnement.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;

  document.querySelectorAll('[data-renouveler]').forEach((b) => b.onclick = async () => {
    await api(`/abonnements/${b.dataset.renouveler}/renouveler`, { method: 'POST' });
    toast('Abonnement renouvelé.');
    router();
  });
  document.querySelectorAll('[data-suspendre-abo]').forEach((b) => b.onclick = async () => {
    await api(`/abonnements/${b.dataset.suspendreAbo}/statut`, { method: 'POST', body: { statut: 'suspendu' } });
    toast('Abonnement suspendu.');
    router();
  });
}

/* ============================================================
   VUE : RENTABILITÉ (§18)
   ============================================================ */
async function vueRentabilite(conteneur) {
  const r = await api('/rentabilite');
  conteneur.innerHTML = `
    <h1 class="titre-page">Rentabilité</h1>
    <p class="sous-titre-page">Période : ${r.periode}</p>
    <div class="grille-cartes">
      <div class="carte-stat"><div class="label">Chiffre d'affaires</div><div class="valeur">${fmtEuros(r.totaux.chiffreAffaires)}</div></div>
      <div class="carte-stat"><div class="label">Coûts IA</div><div class="valeur">${fmtEuros(r.totaux.coutsIA)}</div></div>
      <div class="carte-stat"><div class="label">Coûts techniques</div><div class="valeur">${fmtEuros(r.totaux.coutsTechniques)}</div></div>
      <div class="carte-stat"><div class="label">Marge totale</div><div class="valeur">${fmtEuros(r.totaux.marge)}</div></div>
      <div class="carte-stat"><div class="label">Marge moyenne / client</div><div class="valeur">${fmtEuros(r.totaux.margeMoyenneParClient)}</div></div>
    </div>
    <div class="panneau">
      <table>
        <thead><tr><th>Client</th><th>Forfait</th><th>Revenu</th><th>Coût IA</th><th>Coût technique</th><th>Marge</th></tr></thead>
        <tbody>
          ${r.lignes.map((l) => `
            <tr>
              <td>${l.nomEntreprise}</td><td>${l.forfait}</td>
              <td>${fmtEuros(l.revenu)}</td><td>${fmtEuros(l.coutIA)}</td><td>${fmtEuros(l.coutTechnique)}</td>
              <td style="color:${l.marge >= 0 ? 'var(--vert)' : 'var(--rouge)'};font-weight:600">${fmtEuros(l.marge)}</td>
            </tr>
          `).join('') || '<tr><td colspan="6" style="color:var(--texte-attenue)">Aucune donnée.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

/* ============================================================
   VUE : ALERTES (§22)
   ============================================================ */
async function vueAlertes(conteneur) {
  const alertes = await api('/alertes');
  const icone = { rouge: '🔴', orange: '🟠', bleu: '🔵' };
  conteneur.innerHTML = `
    <h1 class="titre-page">Alertes</h1>
    <p class="sous-titre-page">${alertes.filter((a) => a.statut === 'nouvelle').length} nouvelle(s)</p>
    <div id="liste-alertes">
      ${alertes.map((a) => `
        <div class="alerte-item">
          <div style="font-size:18px">${icone[a.gravite] || '🔵'}</div>
          <div class="msg">
            <div><strong>${a.categorie}</strong> ${badgeStatut(a.statut)}</div>
            <div>${a.message}</div>
            <div class="date">${fmtDateHeure(a.date)}</div>
          </div>
          <div>
            ${a.statut !== 'traitée' ? `<button class="lien-action" data-traiter="${a.id}">Marquer traitée</button>` : ''}
          </div>
        </div>
      `).join('') || '<p style="color:var(--texte-attenue)">Aucune alerte.</p>'}
    </div>
  `;
  document.querySelectorAll('[data-traiter]').forEach((b) => b.onclick = async () => {
    await api(`/alertes/${b.dataset.traiter}/statut`, { method: 'POST', body: { statut: 'traitée' } });
    toast('Alerte marquée comme traitée.');
    router();
    rafraichirBadgeAlertes();
  });
}

/* ============================================================
   VUE : JOURNAL D'AUDIT (§26)
   ============================================================ */
async function vueJournal(conteneur) {
  const journal = await api('/journal');
  conteneur.innerHTML = `
    <h1 class="titre-page">Journal d'audit</h1>
    <p class="sous-titre-page">${journal.length} événement(s) récents</p>
    <div class="panneau">
      <table>
        <thead><tr><th>Utilisateur</th><th>Action</th><th>Cible</th><th>Date</th></tr></thead>
        <tbody>
          ${journal.map((j) => `<tr><td>${j.utilisateur}</td><td>${j.action}</td><td style="color:var(--texte-attenue);font-size:12px">${j.details || j.cible || '—'}</td><td>${fmtDateHeure(j.date)}</td></tr>`).join('') || '<tr><td colspan="4" style="color:var(--texte-attenue)">Aucun événement.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
}

/* ============================================================
   VUE : PARAMÈTRES (§30)
   ============================================================ */
async function vueParametres(conteneur) {
  const seuils = await api('/parametres/seuilsAlerte');
  conteneur.innerHTML = `
    <h1 class="titre-page">Paramètres</h1>
    <div class="panneau">
      <h3 style="margin-top:0">Seuils d'alerte IA (%)</h3>
      <p style="font-size:13px;color:var(--texte-attenue)">Une alerte est générée automatiquement quand un client franchit ces seuils.</p>
      <input id="m-seuils" value="${(seuils.valeur || [50, 80, 90, 100]).join(', ')}" />
      <button class="btn btn-primary" id="btn-save-seuils" style="margin-top:14px">Enregistrer</button>
    </div>
    <div class="panneau">
      <h3 style="margin-top:0">Données de démonstration</h3>
      <p style="font-size:13px;color:var(--texte-attenue)">Cette base ne contient aucune donnée de démonstration par défaut. Pour en générer temporairement afin de tester l'interface, exécutez côté serveur : <code>SEED_AVEC_DEMO=true npm run seed</code>. Le bouton ci-dessous supprime ces données si vous en avez généré.</p>
      <button class="btn btn-danger" id="btn-supprimer-demo">Supprimer les données de démonstration (si présentes)</button>
    </div>
  `;
  document.getElementById('btn-save-seuils').onclick = async () => {
    const valeur = document.getElementById('m-seuils').value.split(',').map((v) => Number(v.trim())).filter((n) => !isNaN(n));
    await api('/parametres/seuilsAlerte', { method: 'PUT', body: { valeur } });
    toast('Seuils enregistrés.');
  };
  document.getElementById('btn-supprimer-demo').onclick = async () => {
    if (!confirm('Supprimer définitivement toutes les données de démonstration ?')) return;
    const r = await api('/donnees-demo/supprimer', { method: 'POST' });
    toast(`${r.supprimes} document(s) supprimé(s).`);
    router();
  };
}

/* ============================================================
   MODAL générique
   ============================================================ */
function ouvrirModal(html, onValider, libelleValider = 'Créer') {
  fermerModal();
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal">
      ${html}
      <div class="modal-actions">
        <button class="btn btn-secondaire" id="modal-annuler">Annuler</button>
        <button class="btn btn-primary" id="modal-valider">${libelleValider}</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  document.getElementById('modal-annuler').onclick = fermerModal;
  document.getElementById('modal-valider').onclick = async () => {
    try { await onValider(); } catch (e) { toast(e.message, 'erreur'); }
  };
  overlay.addEventListener('click', (e) => { if (e.target === overlay) fermerModal(); });
}
function fermerModal() {
  const el = document.getElementById('modal-overlay');
  if (el) el.remove();
}

/* ---------------- Recherche globale (§31) ---------------- */
let timerRecherche = null;
document.getElementById('recherche-globale').addEventListener('input', (e) => {
  clearTimeout(timerRecherche);
  const q = e.target.value.trim();
  const boite = document.getElementById('resultats-recherche');
  if (!q) { boite.classList.add('hidden'); return; }
  timerRecherche = setTimeout(async () => {
    const r = await api(`/recherche?q=${encodeURIComponent(q)}`);
    const groupes = [
      ['Clients', r.clients.map((c) => c.nomEntreprise)],
      ['Applications', r.applications.map((a) => a.nom)],
      ['Factures', r.factures.map((f) => f.numero)],
    ];
    boite.innerHTML = groupes.map(([titre, items]) => items.length ? `
      <div class="groupe-titre">${titre}</div>
      ${items.map((i) => `<div class="item">${i}</div>`).join('')}
    ` : '').join('') || '<div class="item">Aucun résultat.</div>';
    boite.classList.remove('hidden');
  }, 250);
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('.topbar')) document.getElementById('resultats-recherche').classList.add('hidden');
});

/* ---------------- Démarrage ---------------- */
if (TOKEN) demarrerApp();
