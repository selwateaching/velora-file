const { collection } = require('../db/store');

/**
 * §26 — JOURNAL D'AUDIT
 * Appeler logAction() explicitement après chaque action sensible
 * (création client, changement de forfait, suspension, tarifs IA...).
 */
async function logAction({ adminEmail, action, cible, details }) {
  await collection('journalAudit').insert({
    utilisateur: adminEmail || 'système',
    action,
    cible: cible || null,
    details: details || null,
    date: new Date().toISOString(),
  });
}

module.exports = { logAction };
