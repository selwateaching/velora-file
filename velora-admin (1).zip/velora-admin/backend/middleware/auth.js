const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error('JWT_SECRET manquant. Copiez .env.example vers .env et définissez une valeur secrète.');
}

/**
 * §6 / §27 / §28 — Aucune confiance dans le frontend.
 * Le rôle et l'identité de l'administrateur sont vérifiés uniquement
 * via un token signé côté serveur (jamais une variable JS du navigateur).
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Non authentifié.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.role !== 'admin') return res.status(403).json({ error: 'Accès refusé.' });
    req.admin = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Session invalide ou expirée.' });
  }
}

function signAdminToken(admin) {
  return jwt.sign(
    { sub: admin.id, email: admin.email, role: 'admin' },
    JWT_SECRET,
    { expiresIn: '12h' }
  );
}

module.exports = { requireAuth, signAdminToken, JWT_SECRET };
