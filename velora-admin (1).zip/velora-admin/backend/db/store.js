/**
 * COUCHE DE PERSISTANCE — VELORA ADMIN
 * ------------------------------------------------------------
 * Implémentation "collections" façon Firestore, stockée en fichiers
 * JSON locaux (un fichier = une collection). L'API exposée
 * (find, findOne, findById, insert, update, remove, count) est
 * volontairement calquée sur le modèle documentaire de Firestore
 * pour que la migration future soit mécanique :
 *
 *   store.collection('clients').find({statut: 'actif'})
 *     -> devient
 *   db.collection('clients').where('statut','==','actif').get()
 *
 * Aucune clé secrète, aucun contenu envoyé à l'IA n'est stocké ici :
 * uniquement des métadonnées de gestion (conforme §41 RGPD).
 * ------------------------------------------------------------
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function fileFor(collectionName) {
  return path.join(DATA_DIR, `${collectionName}.json`);
}

function loadRaw(collectionName) {
  const file = fileFor(collectionName);
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, '[]', 'utf-8');
    return [];
  }
  const content = fs.readFileSync(file, 'utf-8').trim();
  return content ? JSON.parse(content) : [];
}

function saveRaw(collectionName, docs) {
  const file = fileFor(collectionName);
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(docs, null, 2), 'utf-8');
  fs.renameSync(tmp, file); // écriture atomique simple
}

// Simple lock en mémoire pour éviter les écritures concurrentes corrompues
const locks = new Map();
async function withLock(name, fn) {
  const prev = locks.get(name) || Promise.resolve();
  let release;
  const p = new Promise((res) => (release = res));
  locks.set(name, prev.then(() => p));
  await prev;
  try {
    return await fn();
  } finally {
    release();
  }
}

function matches(doc, query) {
  if (!query) return true;
  return Object.entries(query).every(([k, v]) => {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      // opérateurs simples: {gte:..}, {lte:..}, {in:[...]}
      return Object.entries(v).every(([op, val]) => {
        switch (op) {
          case 'gte': return doc[k] >= val;
          case 'lte': return doc[k] >= val ? doc[k] <= val : false;
          case 'gt': return doc[k] > val;
          case 'lt': return doc[k] < val;
          case 'in': return Array.isArray(val) && val.includes(doc[k]);
          case 'ne': return doc[k] !== val;
          default: return true;
        }
      });
    }
    return doc[k] === v;
  });
}

class Collection {
  constructor(name) {
    this.name = name;
  }

  async find(query = {}, { sort, limit, offset } = {}) {
    return withLock(this.name, async () => {
      let docs = loadRaw(this.name).filter((d) => matches(d, query));
      if (sort) {
        const [field, dir] = sort.startsWith('-') ? [sort.slice(1), -1] : [sort, 1];
        docs = docs.sort((a, b) => (a[field] > b[field] ? 1 : a[field] < b[field] ? -1 : 0) * dir);
      }
      if (offset) docs = docs.slice(offset);
      if (limit) docs = docs.slice(0, limit);
      return docs;
    });
  }

  async findOne(query = {}) {
    const docs = await this.find(query, { limit: 1 });
    return docs[0] || null;
  }

  async findById(id) {
    return this.findOne({ id });
  }

  async insert(data) {
    return withLock(this.name, async () => {
      const docs = loadRaw(this.name);
      const doc = {
        id: data.id || crypto.randomUUID(),
        createdAt: data.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...data,
      };
      docs.push(doc);
      saveRaw(this.name, docs);
      return doc;
    });
  }

  async update(id, patch) {
    return withLock(this.name, async () => {
      const docs = loadRaw(this.name);
      const idx = docs.findIndex((d) => d.id === id);
      if (idx === -1) return null;
      docs[idx] = { ...docs[idx], ...patch, id, updatedAt: new Date().toISOString() };
      saveRaw(this.name, docs);
      return docs[idx];
    });
  }

  async remove(id) {
    return withLock(this.name, async () => {
      const docs = loadRaw(this.name);
      const next = docs.filter((d) => d.id !== id);
      saveRaw(this.name, next);
      return docs.length !== next.length;
    });
  }

  async count(query = {}) {
    const docs = await this.find(query);
    return docs.length;
  }
}

const cache = new Map();
function collection(name) {
  if (!cache.has(name)) cache.set(name, new Collection(name));
  return cache.get(name);
}

module.exports = { collection };
