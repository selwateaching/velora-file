require('dotenv').config();
const bcrypt = require('bcryptjs');
const { collection } = require('./store');

async function seed() {
  console.log('--- Amorçage Velora Admin ---');

  // 1) Premier administrateur (§47 point 4)
  const emailAdmin = process.env.SEED_ADMIN_EMAIL || 'admin@velora-ia.example';
  const motDePasse = process.env.SEED_ADMIN_PASSWORD || 'ChangezMoiImmediatement!2026';
  const adminExistant = await collection('admins').findOne({ email: emailAdmin });
  if (!adminExistant) {
    await collection('admins').insert({
      email: emailAdmin,
      nom: 'Administrateur Velora',
      motDePasseHash: bcrypt.hashSync(motDePasse, 12),
    });
    console.log(`Administrateur créé : ${emailAdmin} / mot de passe : ${motDePasse}`);
    console.log('⚠️  Changez ce mot de passe dès la première connexion.');
  } else {
    console.log('Administrateur déjà présent, ignoré.');
  }

  // 2) Fournisseurs IA
  const fournisseurs = ['anthropic', 'openai', 'google'];
  for (const nom of fournisseurs) {
    const existe = await collection('fournisseursIA').findOne({ nom });
    if (!existe) await collection('fournisseursIA').insert({ nom, statut: 'actif' });
  }

  // 3) Tarifs IA (exemples de septembre 2026, à ajuster dans Paramètres > Fournisseurs IA)
  const tarifsDemo = [
    { fournisseur: 'anthropic', modele: 'claude-sonnet-5', prixEntree: 3, prixSortie: 15 },
    { fournisseur: 'anthropic', modele: 'claude-haiku-4-5-20251001', prixEntree: 0.8, prixSortie: 4 },
    { fournisseur: 'openai', modele: 'gpt-5', prixEntree: 5, prixSortie: 15 },
    { fournisseur: 'google', modele: 'gemini-2.5-pro', prixEntree: 2.5, prixSortie: 10 },
  ];
  for (const t of tarifsDemo) {
    const existe = await collection('tarifsIA').findOne({ fournisseur: t.fournisseur, modele: t.modele, dateFin: null });
    if (!existe) {
      await collection('tarifsIA').insert({
        ...t, unite: 'par_million_tokens', dateEffet: new Date().toISOString(), dateFin: null, statut: 'actif',
      });
    }
  }

  // 4) Paramètre seuils d'alerte
  const seuils = await collection('parametres').findOne({ cle: 'seuilsAlerte' });
  if (!seuils) await collection('parametres').insert({ cle: 'seuilsAlerte', valeur: [50, 80, 90, 100] });

  // 5) Forfaits de démo (§10)
  const forfaitsDemo = [
    { nom: 'ESSENTIEL', prix: 29, limiteTokens: 300_000, comportementLimite: 'blocage' },
    { nom: 'CONFORT', prix: 49, limiteTokens: 1_000_000, comportementLimite: 'validation' },
    { nom: 'PRO', prix: 89, limiteTokens: 3_000_000, comportementLimite: 'credit_supplementaire' },
  ];
  const forfaitIds = {};
  for (const f of forfaitsDemo) {
    let doc = await collection('forfaits').findOne({ nom: f.nom });
    if (!doc) doc = await collection('forfaits').insert({ ...f, periode: 'mensuel', fonctionnalites: [], statut: 'actif' });
    forfaitIds[f.nom] = doc.id;
  }

  // 6) Aucune donnée de démonstration n'est créée par défaut (base propre pour la production).
  // Si vous voulez tout de même des exemples pour tester l'interface, exécutez :
  //   SEED_AVEC_DEMO=true npm run seed
  if (process.env.SEED_AVEC_DEMO === 'true') {
    await creerDonneesDemo(forfaitIds, forfaitsDemo);
  } else {
    console.log('Aucune donnée de démonstration créée (base propre). Pour en générer : SEED_AVEC_DEMO=true npm run seed');
  }

  console.log('--- Amorçage terminé ---');
}

async function creerDonneesDemo(forfaitIds, forfaitsDemo) {
  const dejaDemo = await collection('clients').count({ demo: true });
  if (dejaDemo === 0) {
    const crypto = require('crypto');
    const clientsDemo = [
      { nomEntreprise: 'Garage ABC', nomResponsable: 'Karim B.', email: 'contact@garageabc.example', forfait: 'CONFORT', appNom: 'Garage IA', fournisseurIA: 'anthropic', modeleIA: 'claude-sonnet-5' },
      { nomEntreprise: 'Cabinet Médical Dupont', nomResponsable: 'Dr. Dupont', email: 'contact@cabinet-dupont.example', forfait: 'PRO', appNom: 'Cabinet médical', fournisseurIA: 'openai', modeleIA: 'gpt-5' },
      { nomEntreprise: 'RH Solutions', nomResponsable: 'Amira T.', email: 'contact@rhsolutions.example', forfait: 'ESSENTIEL', appNom: 'CV RH', fournisseurIA: 'anthropic', modeleIA: 'claude-haiku-4-5-20251001' },
      { nomEntreprise: 'Tadriss Formation', nomResponsable: 'Youssef L.', email: 'contact@tadriss.example', forfait: 'CONFORT', appNom: 'Tadriss', fournisseurIA: 'google', modeleIA: 'gemini-2.5-pro' },
    ];

    for (const c of clientsDemo) {
      const client = await collection('clients').insert({
        nomEntreprise: c.nomEntreprise, nomResponsable: c.nomResponsable, email: c.email,
        telephone: '', pays: 'France', adresse: '', forfaitId: forfaitIds[c.forfait],
        statut: 'actif', notes: 'Client de démonstration', dateCreation: new Date().toISOString(), demo: true,
      });

      const app = await collection('applications').insert({
        nom: c.appNom, clientId: client.id,
        identifiantUnique: `velora-${c.appNom.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-demo`,
        appKey: `vk_${crypto.randomBytes(20).toString('hex')}`,
        type: 'personnalisée', version: '1.0.0', dateInstallation: new Date().toISOString(),
        statut: 'active', utiliseIA: true, fournisseurIA: c.fournisseurIA, modeleIA: c.modeleIA,
        environnement: 'production', url: '', notes: '', demo: true,
      });

      await collection('abonnements').insert({
        clientId: client.id, forfaitId: forfaitIds[c.forfait],
        prix: forfaitsDemo.find((f) => f.nom === c.forfait).prix, frequence: 'mensuel',
        dateDebut: new Date().toISOString(),
        prochainEcheance: new Date(Date.now() + 25 * 86400000).toISOString(),
        statut: 'actif', essaiJours: 0, reduction: 0, historique: [], demo: true,
      });

      // Consommation simulée pour peupler le tableau de bord
      const periode = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
      const tokensConsommes = Math.floor(Math.random() * 500_000) + 50_000;
      const compteur = await collection('compteurs').insert({
        clientId: client.id, periode, tokensConsommes,
        coutCumule: Number((tokensConsommes / 1_000_000 * 6).toFixed(2)),
        demandes: Math.floor(tokensConsommes / 600), demo: true,
      });

      for (let i = 0; i < 5; i++) {
        await collection('consommations').insert({
          clientId: client.id, applicationId: app.id, fournisseur: c.fournisseurIA, modele: c.modeleIA,
          tokensEntree: 300 + i * 40, tokensSortie: 500 + i * 60,
          tokensTotal: 800 + i * 100, cout: 0.004 * (i + 1),
          statut: 'succes', erreur: null,
          date: new Date(Date.now() - i * 3600_000).toISOString(), demo: true,
        });
      }
    }
    console.log('Données de démonstration créées (4 clients, applications, abonnements, consommation).');
  } else {
    console.log('Données de démonstration déjà présentes, ignorées.');
  }
}

seed().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
