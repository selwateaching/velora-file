const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  res.json(await collection('forfaits').find({}, { sort: 'prix' }));
});

router.post('/', async (req, res) => {
  const { nom, prix, periode, limiteTokens, limiteDemandes, fonctionnalites, comportementLimite } = req.body || {};
  if (!nom || prix === undefined || !limiteTokens) {
    return res.status(400).json({ error: 'Nom, prix et limiteTokens requis.' });
  }
  const forfait = await collection('forfaits').insert({
    nom, prix, periode: periode || 'mensuel',
    limiteTokens, limiteDemandes: limiteDemandes || null,
    fonctionnalites: fonctionnalites || [],
    // §15 — comportement à 100% : "blocage" | "validation" | "credit_supplementaire" | "forfait_superieur"
    comportementLimite: comportementLimite || 'blocage',
    statut: 'actif',
  });
  await logAction({ adminEmail: req.admin.email, action: 'création forfait', cible: forfait.id, details: nom });
  res.status(201).json(forfait);
});

router.put('/:id', async (req, res) => {
  const forfait = await collection('forfaits').findById(req.params.id);
  if (!forfait) return res.status(404).json({ error: 'Forfait introuvable.' });
  const updated = await collection('forfaits').update(req.params.id, req.body || {});
  await logAction({ adminEmail: req.admin.email, action: 'modification forfait', cible: forfait.id });
  res.json(updated);
});

router.delete('/:id', async (req, res) => {
  const forfait = await collection('forfaits').findById(req.params.id);
  if (!forfait) return res.status(404).json({ error: 'Forfait introuvable.' });
  const clientsAssocies = await collection('clients').count({ forfaitId: req.params.id });
  if (clientsAssocies > 0) {
    return res.status(400).json({ error: `${clientsAssocies} client(s) utilisent ce forfait. Désactivez-le plutôt que de le supprimer.` });
  }
  await collection('forfaits').remove(req.params.id);
  await logAction({ adminEmail: req.admin.email, action: 'suppression forfait', cible: req.params.id });
  res.json({ ok: true });
});

module.exports = router;
