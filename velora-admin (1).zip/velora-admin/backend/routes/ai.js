const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { verifierAutorisation, enregistrerConsommation } = require('../services/consumption');

const router = express.Router();

/**
 * §38/§39 — API CENTRALE VELORA
 * Les applications clientes (garage IA, CV RH, etc.) n'appellent JAMAIS
 * directement un fournisseur IA. Elles appellent CET endpoint, avec une
 * clé d'application (appKey) — jamais une clé de fournisseur IA.
 *
 * Header attendu : X-Velora-App-Key: <clé d'application>
 *
 * Ordre des opérations (§3, §13) :
 *   1. authentifier l'application (clé)
 *   2. identifier client / forfait / limite
 *   3. vérifier l'autorisation (côté serveur, jamais dans le HTML)
 *   4. si autorisé -> [ici serait l'appel réel au fournisseur IA]
 *   5. enregistrer la consommation réelle (tokens, coût)
 *   6. mettre à jour les compteurs + générer les alertes de seuil
 *
 * NOTE IMPORTANTE : l'appel réseau réel vers OpenAI / Anthropic / Gemini
 * n'est volontairement PAS exécuté ici tant que vous n'avez pas configuré
 * vos propres clés API fournisseur dans les variables d'environnement
 * (voir .env.example et README §"Connecter un fournisseur IA"). Sans clé
 * réelle, ce endpoint simule un appel réussi UNIQUEMENT pour que vous
 * puissiez tester le contrôle de limites de bout en bout — ceci est
 * indiqué explicitement dans la réponse (champ "modeSimulation": true).
 */
async function authApplication(req, res, next) {
  const appKey = req.headers['x-velora-app-key'];
  if (!appKey) return res.status(401).json({ error: 'Clé application manquante (en-tête X-Velora-App-Key).' });
  const application = await collection('applications').findOne({ appKey });
  if (!application) return res.status(401).json({ error: 'Clé application invalide.' });
  if (application.statut !== 'active') return res.status(403).json({ error: 'Application non active.' });
  req.application = application;
  next();
}

router.post('/verifier', authApplication, async (req, res) => {
  const result = await verifierAutorisation(req.application.clientId, req.application.id);
  res.json(result);
});

router.post('/consommer', authApplication, async (req, res) => {
  const { tokensEntreeEstimes, promptResume } = req.body || {};
  const autorisation = await verifierAutorisation(req.application.clientId, req.application.id);
  if (!autorisation.autorise) {
    return res.status(403).json(autorisation);
  }

  const fournisseur = req.application.fournisseurIA || 'anthropic';
  const modele = req.application.modeleIA || 'claude-sonnet-5';

  const providerKeyVar = {
    anthropic: 'ANTHROPIC_API_KEY',
    openai: 'OPENAI_API_KEY',
    google: 'GOOGLE_AI_API_KEY',
  }[fournisseur];
  const hasRealKey = providerKeyVar && !!process.env[providerKeyVar];

  let tokensEntree, tokensSortie, statut = 'succes', erreur = null;

  if (hasRealKey) {
    // Emplacement prévu pour l'appel réel au SDK du fournisseur.
    // Exemple (Anthropic) : voir README §"Connecter un fournisseur IA".
    return res.status(501).json({
      error: "Clé fournisseur détectée mais l'appel réel n'est pas câblé dans cette démo. Voir README pour brancher le SDK.",
    });
  } else {
    // Mode simulation explicite — clairement signalé, jamais silencieux (§50)
    tokensEntree = tokensEntreeEstimes || Math.floor(200 + Math.random() * 800);
    tokensSortie = Math.floor(tokensEntree * (0.5 + Math.random() * 1.5));
  }

  const { consommation, compteur } = await enregistrerConsommation({
    clientId: req.application.clientId,
    applicationId: req.application.id,
    fournisseur, modele, tokensEntree, tokensSortie, statut, erreur,
  });

  res.json({
    ok: true,
    modeSimulation: !hasRealKey,
    consommation,
    compteur,
    resume: promptResume || null,
  });
});

// Génère/renouvelle une clé d'application (§39 — rotation des identifiants)
router.post('/applications/:id/regenerer-cle', requireAuth, async (req, res) => {
  const crypto = require('crypto');
  const app = await collection('applications').findById(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application introuvable.' });
  const appKey = `vk_${crypto.randomBytes(20).toString('hex')}`;
  const updated = await collection('applications').update(req.params.id, { appKey });
  res.json({ appKey: updated.appKey });
});

module.exports = router;
