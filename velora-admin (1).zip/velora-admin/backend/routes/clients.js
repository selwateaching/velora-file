const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { statut, recherche } = req.query;
  let clients = await collection('clients').find(statut ? { statut } : {}, { sort: '-createdAt' });
  if (recherche) {
    const q = recherche.toLowerCase();
    clients = clients.filter((c) =>
      [c.nomEntreprise, c.nomResponsable, c.email].some((v) => (v || '').toLowerCase().includes(q))
    );
  }
  res.json(clients);
});

router.get('/:id', async (req, res) => {
  const client = await collection('clients').findById(req.params.id);
  if (!client) return res.status(404).json({ error: 'Client introuvable.' });
  const applications = await collection('applications').find({ clientId: client.id });
  const abonnements = await collection('abonnements').find({ clientId: client.id }, { sort: '-createdAt' });
  res.json({ ...client, applications, abonnements });
});

router.post('/', async (req, res) => {
  const { nomEntreprise, nomResponsable, email, telephone, pays, adresse, forfaitId, notes } = req.body || {};
  if (!nomEntreprise || !email) return res.status(400).json({ error: 'Nom d\'entreprise et email requis.' });

  const client = await collection('clients').insert({
    nomEntreprise, nomResponsable: nomResponsable || '', email, telephone: telephone || '',
    pays: pays || '', adresse: adresse || '', forfaitId: forfaitId || null,
    statut: 'actif', notes: notes || '', dateCreation: new Date().toISOString(),
  });
  await logAction({ adminEmail: req.admin.email, action: 'création client', cible: client.id, details: nomEntreprise });
  res.status(201).json(client);
});

router.put('/:id', async (req, res) => {
  const client = await collection('clients').findById(req.params.id);
  if (!client) return res.status(404).json({ error: 'Client introuvable.' });
  const updated = await collection('clients').update(req.params.id, req.body || {});
  await logAction({ adminEmail: req.admin.email, action: 'modification client', cible: client.id });
  res.json(updated);
});

// §36 — Suspension (pas de suppression, blocage des accès IA)
router.post('/:id/suspendre', async (req, res) => {
  const client = await collection('clients').findById(req.params.id);
  if (!client) return res.status(404).json({ error: 'Client introuvable.' });
  const updated = await collection('clients').update(req.params.id, { statut: 'suspendu' });
  await logAction({ adminEmail: req.admin.email, action: 'suspension client', cible: client.id });
  res.json(updated);
});

router.post('/:id/reactiver', async (req, res) => {
  const client = await collection('clients').findById(req.params.id);
  if (!client) return res.status(404).json({ error: 'Client introuvable.' });
  const updated = await collection('clients').update(req.params.id, { statut: 'actif' });
  await logAction({ adminEmail: req.admin.email, action: 'réactivation client', cible: client.id });
  res.json(updated);
});

// §37 — Archivage (désactivation logique, pas de suppression définitive)
router.post('/:id/archiver', async (req, res) => {
  const client = await collection('clients').findById(req.params.id);
  if (!client) return res.status(404).json({ error: 'Client introuvable.' });
  const updated = await collection('clients').update(req.params.id, { statut: 'archive' });
  await logAction({ adminEmail: req.admin.email, action: 'archivage client', cible: client.id });
  res.json(updated);
});

// §35 — Changement de forfait avec historique conservé
router.post('/:id/changer-forfait', async (req, res) => {
  const { nouveauForfaitId, raison } = req.body || {};
  const client = await collection('clients').findById(req.params.id);
  if (!client) return res.status(404).json({ error: 'Client introuvable.' });
  const nouveauForfait = await collection('forfaits').findById(nouveauForfaitId);
  if (!nouveauForfait) return res.status(400).json({ error: 'Forfait introuvable.' });

  const historique = client.historiqueForfaits || [];
  historique.push({
    ancienForfaitId: client.forfaitId,
    nouveauForfaitId,
    date: new Date().toISOString(),
    raison: raison || '',
    administrateur: req.admin.email,
  });
  const updated = await collection('clients').update(req.params.id, { forfaitId: nouveauForfaitId, historiqueForfaits: historique });
  await logAction({ adminEmail: req.admin.email, action: 'changement de forfait', cible: client.id, details: `${client.forfaitId} -> ${nouveauForfaitId}` });
  res.json(updated);
});

module.exports = router;
