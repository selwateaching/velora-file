const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { periodeCourante } = require('../services/consumption');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const periode = req.query.periode || periodeCourante();
  const [clients, abonnements, compteurs, forfaits] = await Promise.all([
    collection('clients').find(),
    collection('abonnements').find({ statut: 'actif' }),
    collection('compteurs').find({ periode }),
    collection('forfaits').find(),
  ]);
  const forfaitById = Object.fromEntries(forfaits.map((f) => [f.id, f]));

  const lignes = clients.map((client) => {
    const abo = abonnements.find((a) => a.clientId === client.id);
    const revenu = abo ? abo.prix : 0;
    const compteur = compteurs.find((c) => c.clientId === client.id);
    const coutIA = compteur ? compteur.coutCumule : 0;
    const coutTechnique = 2; // estimation forfaitaire d'hébergement, ajustable en paramètres
    const marge = revenu - coutIA - coutTechnique;
    return {
      clientId: client.id,
      nomEntreprise: client.nomEntreprise,
      forfait: forfaitById[client.forfaitId]?.nom || '—',
      revenu, coutIA: Number(coutIA.toFixed(2)), coutTechnique,
      marge: Number(marge.toFixed(2)),
    };
  });

  const totaux = lignes.reduce((acc, l) => ({
    chiffreAffaires: acc.chiffreAffaires + l.revenu,
    coutsIA: acc.coutsIA + l.coutIA,
    coutsTechniques: acc.coutsTechniques + l.coutTechnique,
    marge: acc.marge + l.marge,
  }), { chiffreAffaires: 0, coutsIA: 0, coutsTechniques: 0, marge: 0 });

  totaux.margeMoyenneParClient = lignes.length ? Number((totaux.marge / lignes.length).toFixed(2)) : 0;

  res.json({ periode, lignes: lignes.sort((a, b) => b.marge - a.marge), totaux });
});

module.exports = router;
