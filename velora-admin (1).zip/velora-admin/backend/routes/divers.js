const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');
const { periodeCourante } = require('../services/consumption');

const router = express.Router();
router.use(requireAuth);

/* -------------------- §22 ALERTES -------------------- */
router.get('/alertes', async (req, res) => {
  const { statut } = req.query;
  res.json(await collection('alertes').find(statut ? { statut } : {}, { sort: '-date' }));
});
router.post('/alertes/:id/statut', async (req, res) => {
  const { statut } = req.body || {};
  if (!['nouvelle', 'lue', 'traitée'].includes(statut)) return res.status(400).json({ error: 'Statut invalide.' });
  const updated = await collection('alertes').update(req.params.id, { statut });
  if (!updated) return res.status(404).json({ error: 'Alerte introuvable.' });
  res.json(updated);
});

/* -------------------- §16 CRÉDITS IA -------------------- */
router.get('/credits', async (req, res) => {
  const { clientId } = req.query;
  res.json(await collection('credits').find(clientId ? { clientId } : {}, { sort: '-createdAt' }));
});
router.post('/credits', async (req, res) => {
  const { clientId, montantEuros, quantiteTokens, expiration } = req.body || {};
  if (!clientId || !quantiteTokens) return res.status(400).json({ error: 'clientId et quantiteTokens requis.' });
  const credit = await collection('credits').insert({
    clientId, montantEuros: montantEuros || 0, quantiteTokens, utiliseTokens: 0,
    periode: periodeCourante(),
    dateAchat: new Date().toISOString(),
    expiration: expiration || null,
  });
  await logAction({ adminEmail: req.admin.email, action: 'crédit ajouté', cible: clientId, details: `${quantiteTokens} tokens` });
  res.status(201).json(credit);
});

/* -------------------- §17 HISTORIQUE CONSOMMATION -------------------- */
router.get('/consommations', async (req, res) => {
  const { clientId, applicationId, fournisseur, modele, limit } = req.query;
  const query = {};
  if (clientId) query.clientId = clientId;
  if (applicationId) query.applicationId = applicationId;
  if (fournisseur) query.fournisseur = fournisseur;
  if (modele) query.modele = modele;
  const docs = await collection('consommations').find(query, { sort: '-date', limit: limit ? Number(limit) : 200 });
  res.json(docs);
});
router.get('/compteurs', async (req, res) => {
  const { clientId } = req.query;
  res.json(await collection('compteurs').find(clientId ? { clientId } : {}, { sort: '-periode' }));
});

/* -------------------- §26 JOURNAL D'AUDIT -------------------- */
router.get('/journal', async (req, res) => {
  res.json(await collection('journalAudit').find({}, { sort: '-date', limit: 300 }));
});

/* -------------------- §30 PARAMÈTRES -------------------- */
router.get('/parametres/:cle', async (req, res) => {
  const p = await collection('parametres').findOne({ cle: req.params.cle });
  res.json(p || { cle: req.params.cle, valeur: null });
});
router.put('/parametres/:cle', async (req, res) => {
  const existant = await collection('parametres').findOne({ cle: req.params.cle });
  let doc;
  if (existant) doc = await collection('parametres').update(existant.id, { valeur: req.body.valeur });
  else doc = await collection('parametres').insert({ cle: req.params.cle, valeur: req.body.valeur });
  await logAction({ adminEmail: req.admin.email, action: 'modification paramètre', cible: req.params.cle });
  res.json(doc);
});

/* -------------------- §31 RECHERCHE GLOBALE -------------------- */
router.get('/recherche', async (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  if (!q) return res.json({ clients: [], applications: [], abonnements: [], factures: [] });
  const [clients, applications, abonnements, factures] = await Promise.all([
    collection('clients').find(),
    collection('applications').find(),
    collection('abonnements').find(),
    collection('factures').find(),
  ]);
  res.json({
    clients: clients.filter((c) => [c.nomEntreprise, c.email].some((v) => (v || '').toLowerCase().includes(q))).slice(0, 10),
    applications: applications.filter((a) => (a.nom || '').toLowerCase().includes(q)).slice(0, 10),
    abonnements: abonnements.filter((a) => (a.id || '').toLowerCase().includes(q)).slice(0, 10),
    factures: factures.filter((f) => (f.numero || '').toLowerCase().includes(q)).slice(0, 10),
  });
});

/* -------------------- §33 RAPPORT MENSUEL -------------------- */
router.get('/rapport-mensuel', async (req, res) => {
  const periode = req.query.periode || periodeCourante();
  const [clients, applications, compteurs, abonnements] = await Promise.all([
    collection('clients').find({ statut: 'actif' }),
    collection('applications').find(),
    collection('compteurs').find({ periode }),
    collection('abonnements').find({ statut: 'actif' }),
  ]);
  const revenus = abonnements.reduce((s, a) => s + a.prix, 0);
  const coutIA = compteurs.reduce((s, c) => s + c.coutCumule, 0);
  const consommationTotale = compteurs.reduce((s, c) => s + c.tokensConsommes, 0);
  const forfaits = await collection('forfaits').find();
  const forfaitById = Object.fromEntries(forfaits.map((f) => [f.id, f]));
  const clientsById = Object.fromEntries(clients.map((c) => [c.id, c]));

  let depasse80 = 0, atteint100 = 0;
  for (const c of compteurs) {
    const client = clientsById[c.clientId];
    const f = client && forfaitById[client.forfaitId];
    if (f && f.limiteTokens > 0) {
      const pct = c.tokensConsommes / f.limiteTokens;
      if (pct >= 0.8) depasse80++;
      if (pct >= 1) atteint100++;
    }
  }

  res.json({
    periode,
    clientsActifs: clients.length,
    applications: applications.length,
    revenus: Number(revenus.toFixed(2)),
    coutIA: Number(coutIA.toFixed(2)),
    coutsTechniques: applications.length * 1.14, // estimation forfaitaire simple, ajustable
    margeEstimee: Number((revenus - coutIA).toFixed(2)),
    consommationIA: consommationTotale,
    clientsDepasse80Pourcent: depasse80,
    limitesAtteintes: atteint100,
  });
});

/* -------------------- §46 SUPPRIMER LES DONNÉES DE DÉMO -------------------- */
router.post('/donnees-demo/supprimer', async (req, res) => {
  const collections = ['clients', 'applications', 'forfaits', 'abonnements', 'consommations', 'compteurs', 'alertes', 'credits', 'paiements', 'factures'];
  let total = 0;
  for (const nom of collections) {
    const docs = await collection(nom).find({ demo: true });
    for (const d of docs) {
      await collection(nom).remove(d.id);
      total++;
    }
  }
  await logAction({ adminEmail: req.admin.email, action: 'suppression données de démonstration', details: `${total} documents` });
  res.json({ ok: true, supprimes: total });
});

module.exports = router;
