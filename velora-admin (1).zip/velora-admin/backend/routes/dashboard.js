const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { periodeCourante } = require('../services/consumption');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const [clients, applications, forfaits, abonnements, alertes] = await Promise.all([
    collection('clients').find(),
    collection('applications').find(),
    collection('forfaits').find(),
    collection('abonnements').find(),
    collection('alertes').find({ statut: 'nouvelle' }),
  ]);

  const periode = periodeCourante();
  const compteurs = await collection('compteurs').find({ periode });
  const forfaitById = Object.fromEntries(forfaits.map((f) => [f.id, f]));

  const consommationTotale = compteurs.reduce((s, c) => s + c.tokensConsommes, 0);
  const coutIA = compteurs.reduce((s, c) => s + c.coutCumule, 0);
  const demandes = compteurs.reduce((s, c) => s + c.demandes, 0);

  const clientsProchesLimite = compteurs.filter((c) => {
    const client = clients.find((cl) => cl.id === c.clientId);
    const f = client && forfaitById[client.forfaitId];
    return f && f.limiteTokens > 0 && c.tokensConsommes / f.limiteTokens >= 0.8 && c.tokensConsommes / f.limiteTokens < 1;
  }).length;

  const clientsLimiteAtteinte = compteurs.filter((c) => {
    const client = clients.find((cl) => cl.id === c.clientId);
    const f = client && forfaitById[client.forfaitId];
    return f && f.limiteTokens > 0 && c.tokensConsommes / f.limiteTokens >= 1;
  }).length;

  const revenuMensuel = abonnements
    .filter((a) => a.statut === 'actif')
    .reduce((s, a) => s + (a.prix || 0), 0);

  // Évolution mensuelle (12 derniers mois) — pour graphiques
  const compteursHistoriques = await collection('compteurs').find();
  const parMois = {};
  for (const c of compteursHistoriques) {
    parMois[c.periode] = parMois[c.periode] || { periode: c.periode, tokens: 0, cout: 0 };
    parMois[c.periode].tokens += c.tokensConsommes;
    parMois[c.periode].cout += c.coutCumule;
  }
  const evolution = Object.values(parMois).sort((a, b) => (a.periode > b.periode ? 1 : -1));

  res.json({
    clients: {
      total: clients.length,
      actifs: clients.filter((c) => c.statut === 'actif').length,
      suspendus: clients.filter((c) => c.statut === 'suspendu').length,
      nouveaux30j: clients.filter((c) => Date.now() - new Date(c.dateCreation || c.createdAt).getTime() < 30 * 86400000).length,
    },
    applications: {
      total: applications.length,
      actives: applications.filter((a) => a.statut === 'active').length,
      avecIA: applications.filter((a) => a.utiliseIA).length,
      sansIA: applications.filter((a) => !a.utiliseIA).length,
    },
    abonnements: {
      actifs: abonnements.filter((a) => a.statut === 'actif').length,
      echeanceProche: abonnements.filter((a) => a.prochainEcheance && new Date(a.prochainEcheance) - Date.now() < 7 * 86400000 && a.statut === 'actif').length,
      suspendus: abonnements.filter((a) => a.statut === 'suspendu').length,
      revenuMensuel,
    },
    ia: {
      consommationMoisTokens: consommationTotale,
      coutMoisEuros: Number(coutIA.toFixed(2)),
      nombreDemandes: demandes,
      clientsProchesLimite,
      clientsLimiteAtteinte,
    },
    finance: {
      revenusMois: revenuMensuel,
      coutsIA: Number(coutIA.toFixed(2)),
      coutsTechniques: 0,
      margeEstimee: Number((revenuMensuel - coutIA).toFixed(2)),
    },
    alertesNouvelles: alertes.length,
    evolutionMensuelle: evolution,
  });
});

module.exports = router;
