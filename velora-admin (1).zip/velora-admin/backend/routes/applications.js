const express = require('express');
const crypto = require('crypto');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { clientId, statut, utiliseIA } = req.query;
  const query = {};
  if (clientId) query.clientId = clientId;
  if (statut) query.statut = statut;
  if (utiliseIA !== undefined) query.utiliseIA = utiliseIA === 'true';
  const apps = await collection('applications').find(query, { sort: '-createdAt' });
  res.json(apps);
});

router.get('/:id', async (req, res) => {
  const app = await collection('applications').findById(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application introuvable.' });
  res.json(app);
});

router.post('/', async (req, res) => {
  const { nom, clientId, type, version, utiliseIA, fournisseurIA, modeleIA, environnement, url, notes } = req.body || {};
  if (!nom || !clientId) return res.status(400).json({ error: 'Nom et client requis.' });
  const client = await collection('clients').findById(clientId);
  if (!client) return res.status(400).json({ error: 'Client introuvable.' });

  const app = await collection('applications').insert({
    nom, clientId,
    identifiantUnique: `velora-${nom.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36)}`,
    appKey: `vk_${crypto.randomBytes(20).toString('hex')}`, // §39 — clé d'application (jamais une clé de fournisseur IA)
    type: type || 'personnalisée',
    version: version || '1.0.0',
    dateInstallation: new Date().toISOString(),
    statut: 'active',
    utiliseIA: !!utiliseIA,
    fournisseurIA: fournisseurIA || null,
    modeleIA: modeleIA || null,
    environnement: environnement || 'production',
    url: url || '',
    notes: notes || '',
  });
  await logAction({ adminEmail: req.admin.email, action: 'création application', cible: app.id, details: nom });
  res.status(201).json(app);
});

router.put('/:id', async (req, res) => {
  const app = await collection('applications').findById(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application introuvable.' });
  const updated = await collection('applications').update(req.params.id, req.body || {});
  await logAction({ adminEmail: req.admin.email, action: 'modification application', cible: app.id });
  res.json(updated);
});

router.post('/:id/statut', async (req, res) => {
  const { statut } = req.body || {};
  if (!['active', 'suspendue', 'maintenance', 'archivée'].includes(statut)) {
    return res.status(400).json({ error: 'Statut invalide.' });
  }
  const app = await collection('applications').findById(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application introuvable.' });
  const updated = await collection('applications').update(req.params.id, { statut });
  await logAction({ adminEmail: req.admin.email, action: `statut application -> ${statut}`, cible: app.id });
  res.json(updated);
});

module.exports = router;
