const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { statut, clientId } = req.query;
  const query = {};
  if (statut) query.statut = statut;
  if (clientId) query.clientId = clientId;
  res.json(await collection('abonnements').find(query, { sort: '-createdAt' }));
});

router.post('/', async (req, res) => {
  const { clientId, forfaitId, prix, frequence, essaiJours, reduction } = req.body || {};
  if (!clientId || !forfaitId || prix === undefined) return res.status(400).json({ error: 'clientId, forfaitId, prix requis.' });

  const dateDebut = new Date();
  const prochainEcheance = new Date(dateDebut);
  if (frequence === 'annuel') prochainEcheance.setFullYear(prochainEcheance.getFullYear() + 1);
  else prochainEcheance.setMonth(prochainEcheance.getMonth() + 1);

  const abo = await collection('abonnements').insert({
    clientId, forfaitId, prix, frequence: frequence || 'mensuel',
    dateDebut: dateDebut.toISOString(),
    prochainEcheance: prochainEcheance.toISOString(),
    statut: essaiJours ? 'en_attente' : 'actif',
    essaiJours: essaiJours || 0,
    reduction: reduction || 0,
    historique: [{ evenement: 'création', date: dateDebut.toISOString() }],
  });
  await logAction({ adminEmail: req.admin.email, action: 'création abonnement', cible: abo.id });
  res.status(201).json(abo);
});

router.post('/:id/statut', async (req, res) => {
  const { statut } = req.body || {};
  if (!['actif', 'en_attente', 'suspendu', 'annulé', 'expiré'].includes(statut)) {
    return res.status(400).json({ error: 'Statut invalide.' });
  }
  const abo = await collection('abonnements').findById(req.params.id);
  if (!abo) return res.status(404).json({ error: 'Abonnement introuvable.' });
  const historique = [...(abo.historique || []), { evenement: `statut -> ${statut}`, date: new Date().toISOString() }];
  const updated = await collection('abonnements').update(req.params.id, { statut, historique });
  await logAction({ adminEmail: req.admin.email, action: `abonnement -> ${statut}`, cible: abo.id });
  res.json(updated);
});

router.post('/:id/renouveler', async (req, res) => {
  const abo = await collection('abonnements').findById(req.params.id);
  if (!abo) return res.status(404).json({ error: 'Abonnement introuvable.' });
  const prochain = new Date(abo.prochainEcheance);
  if (abo.frequence === 'annuel') prochain.setFullYear(prochain.getFullYear() + 1);
  else prochain.setMonth(prochain.getMonth() + 1);
  const historique = [...(abo.historique || []), { evenement: 'renouvellement', date: new Date().toISOString() }];
  const updated = await collection('abonnements').update(req.params.id, { prochainEcheance: prochain.toISOString(), statut: 'actif', historique });
  res.json(updated);
});

module.exports = router;
