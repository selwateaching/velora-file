const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

const router = express.Router();
router.use(requireAuth);

// §20 — PAIEMENTS. Aucune donnée bancaire n'est stockée ici (ce champ
// n'existe même pas dans le schéma) : uniquement une référence externe
// (ex: identifiant de transaction Stripe) si un prestataire est branché.
router.get('/', async (req, res) => {
  const { clientId, statut } = req.query;
  const query = {};
  if (clientId) query.clientId = clientId;
  if (statut) query.statut = statut;
  res.json(await collection('paiements').find(query, { sort: '-date' }));
});

router.post('/', async (req, res) => {
  const { clientId, abonnementId, montant, modePaiement, reference, note } = req.body || {};
  if (!clientId || montant === undefined) return res.status(400).json({ error: 'clientId et montant requis.' });
  const paiement = await collection('paiements').insert({
    clientId, abonnementId: abonnementId || null, montant,
    date: new Date().toISOString(), statut: 'payé',
    modePaiement: modePaiement || 'virement', reference: reference || null, note: note || '',
  });
  await logAction({ adminEmail: req.admin.email, action: 'enregistrement paiement', cible: paiement.id, details: `${montant} €` });
  res.status(201).json(paiement);
});

router.post('/:id/statut', async (req, res) => {
  const { statut } = req.body || {};
  if (!['payé', 'en_attente', 'échoué', 'remboursé'].includes(statut)) {
    return res.status(400).json({ error: 'Statut invalide.' });
  }
  const paiement = await collection('paiements').findById(req.params.id);
  if (!paiement) return res.status(404).json({ error: 'Paiement introuvable.' });
  const updated = await collection('paiements').update(req.params.id, { statut });
  res.json(updated);
});

// §21 — FACTURES
router.get('/factures', async (req, res) => {
  const { clientId } = req.query;
  res.json(await collection('factures').find(clientId ? { clientId } : {}, { sort: '-date' }));
});

router.post('/factures', async (req, res) => {
  const { clientId, periode, montantHT, tauxTVA } = req.body || {};
  if (!clientId || montantHT === undefined) return res.status(400).json({ error: 'clientId et montantHT requis.' });
  const tva = tauxTVA ?? 20;
  const montantTVA = Number((montantHT * (tva / 100)).toFixed(2));
  const montantTTC = Number((montantHT + montantTVA).toFixed(2));
  const count = await collection('factures').count();
  const numero = `VEL-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
  const facture = await collection('factures').insert({
    numero, clientId, periode: periode || null, date: new Date().toISOString(),
    montantHT, tauxTVA: tva, montantTVA, montantTTC, statut: 'émise',
  });
  await logAction({ adminEmail: req.admin.email, action: 'émission facture', cible: facture.id, details: numero });
  res.status(201).json(facture);
});

module.exports = router;
