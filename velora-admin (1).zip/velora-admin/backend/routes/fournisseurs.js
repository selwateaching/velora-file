const express = require('express');
const { collection } = require('../db/store');
const { requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  res.json(await collection('fournisseursIA').find());
});

router.post('/', async (req, res) => {
  const { nom, statut } = req.body || {};
  if (!nom) return res.status(400).json({ error: 'Nom requis.' });
  const f = await collection('fournisseursIA').insert({ nom, statut: statut || 'actif' });
  res.status(201).json(f);
});

// Tarifs (historisés) — §12
router.get('/tarifs', async (req, res) => {
  const { fournisseur, modele } = req.query;
  const query = {};
  if (fournisseur) query.fournisseur = fournisseur;
  if (modele) query.modele = modele;
  res.json(await collection('tarifsIA').find(query, { sort: '-dateEffet' }));
});

router.post('/tarifs', async (req, res) => {
  const { fournisseur, modele, prixEntree, prixSortie, unite } = req.body || {};
  if (!fournisseur || !modele || prixEntree === undefined || prixSortie === undefined) {
    return res.status(400).json({ error: 'fournisseur, modele, prixEntree, prixSortie requis.' });
  }
  // Ferme l'ancien tarif actif (historique conservé, §12)
  const ancien = await collection('tarifsIA').findOne({ fournisseur, modele, dateFin: null });
  const now = new Date().toISOString();
  if (ancien) {
    await collection('tarifsIA').update(ancien.id, { dateFin: now, statut: 'archivé' });
  }
  const nouveau = await collection('tarifsIA').insert({
    fournisseur, modele, prixEntree, prixSortie,
    unite: unite || 'par_million_tokens',
    dateEffet: now, dateFin: null, statut: 'actif',
  });
  await logAction({ adminEmail: req.admin.email, action: 'mise à jour tarif IA', cible: `${fournisseur}/${modele}`, details: `entrée ${prixEntree}, sortie ${prixSortie}` });
  res.status(201).json(nouveau);
});

module.exports = router;
