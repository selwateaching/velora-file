const express = require('express');
const bcrypt = require('bcryptjs');
const { collection } = require('../db/store');
const { signAdminToken, requireAuth } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

const router = express.Router();

// §6 — Connexion administrateur
router.post('/login', async (req, res) => {
  const { email, motDePasse } = req.body || {};
  if (!email || !motDePasse) return res.status(400).json({ error: 'Email et mot de passe requis.' });

  const admin = await collection('admins').findOne({ email: String(email).toLowerCase() });
  if (!admin) return res.status(401).json({ error: 'Identifiants invalides.' });

  const ok = bcrypt.compareSync(motDePasse, admin.motDePasseHash);
  if (!ok) return res.status(401).json({ error: 'Identifiants invalides.' });

  const token = signAdminToken(admin);
  await logAction({ adminEmail: admin.email, action: 'connexion' });
  res.json({ token, admin: { id: admin.id, email: admin.email, nom: admin.nom } });
});

router.post('/logout', requireAuth, async (req, res) => {
  await logAction({ adminEmail: req.admin.email, action: 'deconnexion' });
  res.json({ ok: true });
});

// Vérifie la session et retourne le profil admin courant
router.get('/me', requireAuth, async (req, res) => {
  const admin = await collection('admins').findById(req.admin.sub);
  if (!admin) return res.status(401).json({ error: 'Session invalide.' });
  res.json({ id: admin.id, email: admin.email, nom: admin.nom });
});

// §6 — Mot de passe oublié (génère un jeton de réinitialisation ; l'envoi d'email réel
// nécessite un fournisseur SMTP configuré — voir README §Notifications)
router.post('/mot-de-passe-oublie', async (req, res) => {
  const { email } = req.body || {};
  const admin = await collection('admins').findOne({ email: String(email || '').toLowerCase() });
  // On ne révèle jamais si l'email existe ou non (sécurité)
  if (admin) {
    const crypto = require('crypto');
    const resetToken = crypto.randomBytes(24).toString('hex');
    await collection('admins').update(admin.id, {
      resetToken,
      resetTokenExpire: new Date(Date.now() + 3600_000).toISOString(),
    });
    // TODO production : envoyer resetToken par email via un fournisseur SMTP/Transactionnel
  }
  res.json({ ok: true, message: 'Si ce compte existe, un email de réinitialisation a été envoyé.' });
});

router.post('/reinitialiser-mot-de-passe', async (req, res) => {
  const { resetToken, nouveauMotDePasse } = req.body || {};
  if (!resetToken || !nouveauMotDePasse) return res.status(400).json({ error: 'Champs manquants.' });
  const admin = await collection('admins').findOne({ resetToken });
  if (!admin || new Date(admin.resetTokenExpire) < new Date()) {
    return res.status(400).json({ error: 'Jeton invalide ou expiré.' });
  }
  const motDePasseHash = bcrypt.hashSync(nouveauMotDePasse, 12);
  await collection('admins').update(admin.id, { motDePasseHash, resetToken: null, resetTokenExpire: null });
  res.json({ ok: true });
});

module.exports = router;
