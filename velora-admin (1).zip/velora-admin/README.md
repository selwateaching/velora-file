# VELORA ADMIN — Centrale de pilotage Velora IA

Outil d'administration **privé** pour gérer vos clients, applications, forfaits, consommation IA, abonnements et rentabilité depuis un seul endroit.

> Cette documentation est écrite pour une personne qui n'est pas développeuse experte, conformément au cahier des charges (§47).

---

## 1. Ce qui a été construit (état réel)

### ✅ Fonctionnel et réellement connecté (pas une maquette)
- Authentification administrateur sécurisée (JWT + mots de passe hashés bcrypt, jamais en clair)
- Gestion des clients (créer, modifier, suspendre, réactiver, archiver, changer de forfait avec historique)
- Gestion des applications (créer, associer à un client, activer/suspendre/archiver)
- Gestion des forfaits (100% configurables depuis l'interface, sans toucher au code)
- Fournisseurs IA et tarifs **historisés** (jamais codés en dur — voir `backend/services/pricing.js`)
- **Contrôle des limites côté serveur** (jamais dans le navigateur) — voir `backend/services/consumption.js`
- Génération automatique des alertes de seuil (50/80/90/100%, configurables)
- Compteurs de consommation mensuels, avec conservation de l'historique (§34)
- Tableau de bord avec agrégations en temps réel + graphique d'évolution
- Rentabilité par client (revenu, coût IA, marge)
- Abonnements (création, renouvellement, suspension)
- Paiements et factures (sans jamais stocker de données bancaires)
- Journal d'audit automatique de toutes les actions sensibles
- Recherche globale
- Base livrée **propre, sans données de démonstration** (uniquement votre compte admin + 3 forfaits de référence ESSENTIEL/CONFORT/PRO à ajuster ou supprimer). Des données d'exemple restent disponibles à la demande (`SEED_AVEC_DEMO=true npm run seed`) mais ne sont jamais créées par défaut.
- API centrale sécurisée par clé d'application, pour que vos applications clientes (Garage IA, CV RH...) appellent Velora au lieu d'appeler un fournisseur IA directement

### ⚠️ Limites honnêtes de cette version (à faire pour la production réelle)
- **Aucun vrai projet Firebase n'a été créé.** Je ne peux pas créer de projet Google Cloud/Firebase à votre place — cela nécessite vos identifiants. La base de données utilisée ici est un stockage fichier local avec **exactement la même structure de collections** que celle prévue pour Firestore (§52), pour une migration mécanique (voir section 6 ci-dessous).
- **Aucun appel réel à un fournisseur IA n'est câblé.** Sans clé API fournisseur configurée, le endpoint `/api/ai/consommer` fonctionne en **mode simulation explicite** (le champ `modeSimulation: true` l'indique toujours dans la réponse) afin que vous puissiez tester tout le contrôle de limites de bout en bout. Le point d'intégration réel est documenté en section 8.
- **Stripe n'est pas branché.** L'architecture est prête (voir `backend/routes/paiements.js` et `.env.example`), mais l'intégration réelle nécessite votre compte Stripe.
- **Les emails/SMS ne sont pas envoyés.** L'architecture prévoit les points d'insertion (voir `backend/routes/auth.js`, mot de passe oublié), mais aucun fournisseur SMTP n'est branché.
- **Export PDF/CSV des rapports** n'est pas encore implémenté (prévu §32, §21) — à ajouter dans une prochaine itération.
- **Espace client final** (§24) : l'architecture est prête (règles Firestore incluses) mais l'interface n'a pas été développée, comme autorisé par le cahier des charges.

Rien de ce qui précède n'est simulé silencieusement : chaque limite est indiquée explicitement dans le code ou la réponse API, conformément à votre consigne §50.

---

## 2. Structure du projet

```
velora-admin/
├── firestore.rules          # Règles de sécurité prêtes pour la migration Firebase
├── README.md                 # Ce document
└── backend/
    ├── server.js              # Point d'entrée du serveur
    ├── db/
    │   ├── store.js            # Couche de persistance (collections façon Firestore)
    │   └── seed.js             # Création de l'admin + données de démo
    ├── middleware/
    │   ├── auth.js             # Vérification JWT côté serveur
    │   └── audit.js             # Journal d'audit
    ├── services/
    │   ├── pricing.js           # Calcul de coût IA (tarifs centralisés)
    │   └── consumption.js       # Contrôle des limites + alertes de seuil
    ├── routes/                 # Toutes les routes API (une par module)
    ├── data/                    # Fichiers JSON = vos "collections" (créé automatiquement)
    ├── public/                  # Frontend (HTML/CSS/JS, aucun framework requis)
    ├── .env.example              # Variables à copier vers .env
    └── package.json
```

---

## 3. Installation (première fois)

**Pré-requis :** Node.js 18 ou supérieur installé sur votre ordinateur.

1. Ouvrez un terminal dans le dossier `velora-admin/backend`.
2. Installez les dépendances :
   ```
   npm install
   ```
3. Copiez le fichier de configuration :
   ```
   cp .env.example .env
   ```
4. Ouvrez `.env` et changez au minimum :
   - `JWT_SECRET` → une longue chaîne aléatoire (ex: générez-en une sur https://www.uuidgenerator.net/)
   - `SEED_ADMIN_EMAIL` et `SEED_ADMIN_PASSWORD` → vos identifiants administrateur
5. Créez votre premier administrateur (base propre, sans aucune donnée de démonstration) :
   ```
   npm run seed
   ```
   Cette commande crée uniquement : votre compte admin, les fournisseurs IA (Anthropic/OpenAI/Google), des tarifs IA de référence, et 3 forfaits d'exemple (ESSENTIEL/CONFORT/PRO) que vous pouvez modifier ou supprimer immédiatement dans **Forfaits**. Aucun client ni application fictifs n'est créé.
6. Démarrez l'application :
   ```
   npm start
   ```
7. Ouvrez votre navigateur sur **http://localhost:4000** et connectez-vous avec les identifiants définis à l'étape 4.

---

## 4. Créer un client

1. Dans le menu, cliquez sur **Clients** → **+ Nouveau client**.
2. Remplissez le nom de l'entreprise, l'email, et choisissez un forfait.
3. Le client est créé avec le statut "actif".

## 5. Créer un forfait

1. Menu **Forfaits** → **+ Nouveau forfait**.
2. Définissez le nom, le prix, la limite de tokens IA par mois, et le comportement à 100% :
   - **Blocage** : l'IA s'arrête.
   - **Validation admin** : vous devez autoriser manuellement la suite.
   - **Recharge possible** : le client peut acheter des crédits (§16).
   - **Upgrade proposé** : le client peut passer à un forfait supérieur.

## 6. Connecter une application cliente

1. Menu **Applications** → **+ Nouvelle application**, associez-la à un client, cochez "Utilise l'IA" si besoin.
2. Une **clé d'application** (`appKey`) est générée automatiquement — c'est cette clé que votre application (Garage IA, CV RH, etc.) utilisera pour appeler Velora, JAMAIS une clé de fournisseur IA.
3. Dans votre application cliente, chaque appel IA doit passer par Velora :
   ```
   POST https://votre-domaine.com/api/ai/consommer
   Headers: X-Velora-App-Key: <la clé de l'application>
   ```
   Velora vérifie automatiquement le client, le forfait, la limite, puis enregistre la consommation réelle.

## 7. Tester la consommation IA (mode simulation)

Tant qu'aucune clé de fournisseur IA réelle n'est configurée, chaque appel à `/api/ai/consommer` simule une consommation réaliste (tokens aléatoires plausibles) pour que vous puissiez observer :
- la mise à jour des compteurs en temps réel dans le tableau de bord,
- la génération automatique des alertes à 50/80/90/100%,
- le blocage effectif une fois la limite atteinte (selon le comportement configuré sur le forfait).

## 8. Connecter un vrai fournisseur IA (Anthropic / OpenAI / Google)

1. Ajoutez votre clé API dans `.env` (ex: `ANTHROPIC_API_KEY=sk-ant-...`). **Ne mettez jamais cette clé dans le frontend.**
2. Ouvrez `backend/routes/ai.js`, repérez le bloc `if (hasRealKey) { ... }` dans la route `/consommer`.
3. Remplacez le `return res.status(501)...` par un appel réel au SDK du fournisseur, par exemple pour Anthropic :
   ```js
   const Anthropic = require('@anthropic-ai/sdk');
   const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
   const reponse = await client.messages.create({
     model: modele,
     max_tokens: 1000,
     messages: [{ role: 'user', content: req.body.prompt }],
   });
   tokensEntree = reponse.usage.input_tokens;
   tokensSortie = reponse.usage.output_tokens;
   ```
4. Le reste (enregistrement de la consommation, calcul du coût, alertes) fonctionne déjà sans modification.

## 9. Ajouter un nouveau fournisseur IA

1. Menu **Fournisseurs IA** → **+ Mettre à jour un tarif**, renseignez le nom du fournisseur, le modèle et les prix.
2. Le système calculera automatiquement les coûts pour ce fournisseur dès qu'une application l'utilisera — aucune modification de code nécessaire pour la tarification.

## 10. Déployer en production

Options simples, du plus facile au plus robuste :
- **Render / Railway / Fly.io** : connectez votre dépôt Git, définissez les variables d'environnement (celles de `.env`), déployez le dossier `backend`.
- **VPS classique (ex: OVH, Hetzner)** avec Node.js + un reverse proxy Nginx en HTTPS (obligatoire, §27) + `pm2` pour garder le serveur actif.
- Quelle que soit l'option, pensez à :
  - Générer un `JWT_SECRET` unique de production,
  - Changer immédiatement le mot de passe administrateur par défaut,
  - Activer HTTPS (Let's Encrypt est gratuit),
  - Sauvegarder régulièrement le dossier `backend/data/`.

## 11. Sauvegarder / restaurer

- **Sauvegarder** : copiez simplement le dossier `backend/data/` (contient tous les fichiers JSON = toutes vos données).
- **Restaurer** : remplacez le dossier `backend/data/` par une sauvegarde précédente, puis redémarrez le serveur.

---

## 6. Migrer vers Firebase (Firestore + Authentication)

La couche `backend/db/store.js` expose une API volontairement identique au modèle Firestore (`find`, `findOne`, `insert`, `update`, `remove`). Pour migrer :

1. Créez un projet Firebase et activez Firestore + Authentication.
2. Installez `firebase-admin` : `npm install firebase-admin`.
3. Remplacez le contenu de `store.js` par une implémentation utilisant `admin.firestore().collection(name)` avec la même signature de méthodes — aucune route (`routes/*.js`) n'a besoin d'être modifiée, car elles n'appellent que `collection(name).find(...)`, etc.
4. Déployez les règles fournies dans `firestore.rules` :
   ```
   firebase deploy --only firestore:rules
   ```
5. Remplacez `middleware/auth.js` par une vérification via `admin.auth().verifyIdToken()` si vous souhaitez utiliser Firebase Authentication au lieu du JWT local.

---

## 7. Suite des tests réalisés (§48)

| # | Test | Résultat |
|---|------|----------|
| 1 | Création d'un client | ✅ Testé via API (`POST /api/clients`) |
| 2 | Création d'un forfait | ✅ 3 forfaits de démo créés et fonctionnels |
| 3 | Association client/application | ✅ Vérifié (l'application refuse une association à un mauvais client) |
| 4 | Appel IA (simulation) | ✅ `POST /api/ai/consommer` testé, réponse `modeSimulation: true` |
| 5 | Enregistrement des tokens | ✅ Persisté dans `consommations` + `compteurs` |
| 6 | Calcul du coût | ✅ Calculé via tarifs centralisés (`pricing.js`) |
| 7 | Alerte à 80% | ✅ Génération automatique testée dans `verifierEtCreerAlertes` |
| 8 | Blocage à 100% | ✅ `verifierAutorisation` refuse l'appel selon le `comportementLimite` du forfait |
| 9 | Nouveau mois | ✅ Les compteurs sont séparés par `periode` (ex: `2026-09`), historique conservé |
| 10 | Changement de forfait | ✅ Historique conservé dans `client.historiqueForfaits` |
| 11 | Suspension client | ✅ Bloque les appels IA (`verifierAutorisation` vérifie `statut !== 'suspendu'`) |
| 12 | Tentative d'accès non autorisé | ✅ Testé : `401` sans token sur toutes les routes admin |
| 13 | Modification du forfait depuis le frontend | ✅ Impossible : le calcul de limite est fait uniquement côté serveur, la valeur envoyée par le client n'est jamais utilisée pour les vérifications |
| 14 | Accès aux données d'un autre client | ✅ Chaque `appKey` est liée à un seul client ; les vérifications comparent systématiquement `application.clientId` |
| 15 | Erreur fournisseur IA | ⚠️ Prévu dans la structure (champ `erreur` sur `consommations`), à activer lors du branchement réel du SDK fournisseur (section 8) |

---

## 8. Prochaines étapes recommandées

1. Brancher un vrai fournisseur IA (section 8 ci-dessus).
2. Créer votre projet Firebase et migrer le stockage (section 6) pour la scalabilité en production.
3. Intégrer Stripe pour les paiements réels.
4. Ajouter l'export PDF des rapports mensuels et des factures.
5. Développer l'espace client final (les règles de sécurité sont déjà prêtes).
